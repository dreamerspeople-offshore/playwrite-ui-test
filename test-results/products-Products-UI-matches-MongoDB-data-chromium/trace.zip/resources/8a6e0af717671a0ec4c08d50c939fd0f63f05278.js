"use strict";
(self["webpackChunkecommerce_project"] = self["webpackChunkecommerce_project"] || []).push([["main"],{

/***/ 94114:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _core_default_layout_default_layout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/default-layout/default-layout.component */ 85704);
/* harmony import */ var _modules_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modules/dashboard/dashboard.component */ 69786);
/* harmony import */ var _modules_auth_login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/auth/login/login.component */ 75453);
/* harmony import */ var _modules_auth_register_register_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modules/auth/register/register.component */ 51805);
/* harmony import */ var _modules_auth_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modules/auth/reset-password/reset-password.component */ 91025);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37580);








const routes = [
// {
//   path: '',
//   redirectTo: 'login',
//   pathMatch: 'full'
// },
{
  path: '',
  component: _core_default_layout_default_layout_component__WEBPACK_IMPORTED_MODULE_0__.DefaultLayoutComponent,
  // canActivate: [authGuard],
  data: {
    title: 'Home'
  },
  children: [{
    path: 'users',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_sweetalert2_dist_sweetalert2_all_js"), __webpack_require__.e("src_app_modules_user_user_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/user/user.module */ 9697)).then(m => m.UserModule)
  }, {
    path: 'product',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_angular_cdk_fesm2022_collections_mjs-node_modules_angular_cdk_fesm2022_p-c9450e"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_button_mjs-node_modules_angular_material_fesm2-e67351"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_form-field_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_snack-bar_mjs"), __webpack_require__.e("default-src_app_uties_helper_ts-node_modules_moment_moment_js-node_modules_angular_material_f-b0c523"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_chips_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_expansion_mjs"), __webpack_require__.e("default-src_app_modules_product_product_service_ts-node_modules_angular_material_fesm2022_aut-3fa2fb"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_radio_mjs-node_modules_lodash-es_includes_js"), __webpack_require__.e("src_app_modules_product_product_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/product/product.module */ 8373)).then(m => m.ProductModule)
  }, {
    path: 'category',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_angular_cdk_fesm2022_collections_mjs-node_modules_angular_cdk_fesm2022_p-c9450e"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_expansion_mjs"), __webpack_require__.e("default-src_app_modules_common_custom-graph_custom-graph_module_ts"), __webpack_require__.e("src_app_modules_category_category_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/category/category.module */ 48555)).then(m => m.CategoryModule)
  }, {
    path: 'order-dashboard',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_angular_cdk_fesm2022_collections_mjs-node_modules_angular_cdk_fesm2022_p-c9450e"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_button_mjs-node_modules_angular_material_fesm2-e67351"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_form-field_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_snack-bar_mjs"), __webpack_require__.e("default-src_app_uties_helper_ts-node_modules_moment_moment_js-node_modules_angular_material_f-b0c523"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_chips_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_expansion_mjs"), __webpack_require__.e("default-src_app_modules_product_product_service_ts-node_modules_angular_material_fesm2022_aut-3fa2fb"), __webpack_require__.e("default-src_app_modules_order-dashboard_order-dashboard_service_ts-node_modules_angular_mater-ea039f"), __webpack_require__.e("common"), __webpack_require__.e("src_app_modules_order-dashboard_order-dashboard_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/order-dashboard/order-dashboard.module */ 38313)).then(m => m.OrderDashboardModule)
  }, {
    path: 'data-board',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_angular_cdk_fesm2022_collections_mjs-node_modules_angular_cdk_fesm2022_p-c9450e"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_button_mjs-node_modules_angular_material_fesm2-e67351"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_form-field_mjs"), __webpack_require__.e("default-src_app_uties_helper_ts-node_modules_moment_moment_js-node_modules_angular_material_f-b0c523"), __webpack_require__.e("default-src_app_modules_common_custom-graph_custom-graph_module_ts"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_radio_mjs-node_modules_lodash-es_includes_js"), __webpack_require__.e("default-src_app_modules_order-dashboard_order-dashboard_service_ts-node_modules_angular_mater-ea039f"), __webpack_require__.e("src_app_modules_interactivedataboard_interactivedataboard_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/interactivedataboard/interactivedataboard.module */ 26099)).then(m => m.InteractivedataboardModule)
  }, {
    path: 'json-editor',
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_modules_jsoneditor_jsoneditor_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./modules/jsoneditor/jsoneditor.module */ 2073)).then(m => m.JsoneditorModule)
  }, {
    path: 'multi-file-uploader',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_angular_cdk_fesm2022_collections_mjs-node_modules_angular_cdk_fesm2022_p-c9450e"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_button_mjs-node_modules_angular_material_fesm2-e67351"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_snack-bar_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_divider_mjs-node_modules_angular_material_fesm-d37840"), __webpack_require__.e("src_app_modules_multi-file-upload_multi-file-upload_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/multi-file-upload/multi-file-upload.module */ 48157)).then(m => m.MultiFileUploadModule)
  }, {
    path: 'multi-file-uploader2',
    loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_angular_cdk_fesm2022_collections_mjs-node_modules_angular_cdk_fesm2022_p-c9450e"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_button_mjs-node_modules_angular_material_fesm2-e67351"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_form-field_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_snack-bar_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_chips_mjs"), __webpack_require__.e("default-node_modules_angular_material_fesm2022_divider_mjs-node_modules_angular_material_fesm-d37840"), __webpack_require__.e("common"), __webpack_require__.e("src_app_modules_ngx-multi-file-upload_ngx-multi-file-upload_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/ngx-multi-file-upload/ngx-multi-file-upload.module */ 30633)).then(m => m.NgxMultiFileUploadModule)
  }]
}, {
  path: 'login',
  // canActivate: [authGuard],
  component: _modules_auth_login_login_component__WEBPACK_IMPORTED_MODULE_2__.LoginComponent,
  data: {
    title: 'Login Page'
  }
}, {
  path: 'dashboard',
  // canActivate: [authGuard],
  component: _modules_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_1__.DashboardComponent,
  data: {
    title: 'Login Page'
  }
}, {
  path: 'register',
  component: _modules_auth_register_register_component__WEBPACK_IMPORTED_MODULE_3__.RegisterComponent,
  data: {
    title: 'Register Page'
  }
}, {
  path: 'reset-password',
  component: _modules_auth_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_4__.ResetPasswordComponent,
  data: {
    title: 'Reset Password Page'
  }
}, {
  path: '**',
  redirectTo: 'product'
}];
class AppRoutingModule {
  static {
    this.ɵfac = function AppRoutingModule_Factory(t) {
      return new (t || AppRoutingModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
      type: AppRoutingModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forRoot(routes), _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
  });
})();

/***/ }),

/***/ 20092:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);



class AppComponent {
  constructor(router) {
    this.router = router;
    this.title = 'Ecommerce';
  }
  ngOnInit() {
    // Listen to route changes
    this.router.events.subscribe(event => {
      if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_0__.NavigationEnd) {
        this.showSkipLink();
      }
    });
    console.log(this.transformUrl('https://abc-dev.net'));
    // https://abcdef-dev.np.net
    console.log(this.transformUrl('https://abc-dev.x.net'));
    console.log(this.transformUrl('https://abc.x.net'));
    // https://abcdef-dev.np.x.net
    console.log(this.transformUrl('https://ABC-DEV.X.NET'));
    // https://abcdef-DEV.np.X.NET
    console.log(this.transformUrl('http://AbC-innovation.Service.Net'));
    console.log(this.transformUrl('http://AbC-nonprod.x.Net/xauth/Token'));
    console.log(this.transformUrl('https://AbC.x.Net/xauth/Token'));
    console.log(this.transformUrl('https://xyz-dev.net'));
    // https://xyzdef-dev.np.net
    console.log(this.transformUrl('https://xyz-dev.x.net'));
    console.log(this.transformUrl('https://xyz.x.net'));
    // https://xyzdef-dev.np.x.net
    console.log(this.transformUrl('https://xyz-DEV.X.NET'));
    // https://xyzdef-DEV.np.X.NET
    console.log(this.transformUrl('http://xyz-innovation.Service.Net'));
    console.log(this.transformUrl('http://xyz-nonprod.x.Net/xauth/Token'));
  }
  // getUpdatedUrl(url) {
  //   url = url.replace(/^(https?:\/\/)abc/i, '$1abcdef');
  //   url = url.replace(/\.([A-Za-z0-9]+)(\/|$)/, '.np.$1$2');
  //   return url;
  // }
  transformUrl(url) {
    const baseMap = {
      abc: 'abcdef',
      xyz: 'xyzmk'
    };
    let updated = url;
    // Extract hostname
    const hostnameMatch = updated.match(/^(https?:\/\/)([^\/]+)/i);
    if (!hostnameMatch) return updated;
    const protocol = hostnameMatch[1];
    const fullHost = hostnameMatch[2];
    const firstLabel = fullHost.split('.')[0];
    // Check all base keys
    for (const base in baseMap) {
      const replacement = baseMap[base];
      // Case-insensitive check if first label starts with the base
      if (firstLabel.toLowerCase().startsWith(base.toLowerCase())) {
        // Replace starting base
        const baseRegex = new RegExp(`^(https?:\\/\\/)(` + base + `)(?=[.-])`, 'i');
        updated = updated.replace(baseRegex, `$1${replacement}`);
        // ALWAYS insert .np after first label
        updated = updated.replace(/^(https?:\/\/[^\/]+?)(\.)/, '$1.np$2');
        break; // stop after first match
      }
    }
    return updated;
  }
  skipToContent(event) {
    event.preventDefault();
    const mainContent = document.querySelector('#main-content');
    const skipContainer = document.querySelector('#skip-container');
    if (mainContent) {
      mainContent.scrollIntoView({
        behavior: 'smooth'
      });
      mainContent.focus();
      // Hide the skip button after clicking
      if (skipContainer) {
        skipContainer.style.display = 'none';
      }
    }
  }
  showSkipLink() {
    // Show the skip button when the page changes
    const skipContainer = document.querySelector('#skip-container');
    if (skipContainer) {
      skipContainer.style.display = 'block';
    }
  }
  static {
    this.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_0__.Router));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 4,
      vars: 0,
      consts: [["id", "skip-container"], ["href", "#", 1, "skip-link", 3, "click", "keydown.enter"]],
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppComponent_Template_a_click_1_listener($event) {
            return ctx.skipToContent($event);
          })("keydown.enter", function AppComponent_Template_a_keydown_enter_1_listener($event) {
            return ctx.skipToContent($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Skip to Content");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "router-outlet");
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterOutlet],
      styles: [".skip-link[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -40px;\n  left: 10px;\n  background: #000;\n  color: #fff;\n  padding: 10px;\n  text-decoration: none;\n  z-index: 1000;\n  transition: top 0.3s ease;\n}\n\n.skip-link[_ngcontent-%COMP%]:focus {\n  top: 10px;\n  left: 50%;\n  z-index: 9999;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsU0FBQTtFQUNFLFNBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQUNKIiwic291cmNlc0NvbnRlbnQiOlsiLnNraXAtbGluayB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogLTQwcHg7XHJcbiAgbGVmdDogMTBweDtcclxuICBiYWNrZ3JvdW5kOiAjMDAwO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbiAgdHJhbnNpdGlvbjogdG9wIDAuM3MgZWFzZTtcclxufVxyXG5cclxuLnNraXAtbGluazpmb2N1cyB7XHJcbiAgdG9wOiAxMHB4O1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgei1pbmRleDogOTk5OTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 50635:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/platform-browser */ 80436);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 94114);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 20092);
/* harmony import */ var _core_default_layout_default_layout_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/default-layout/default-layout.module */ 8647);
/* harmony import */ var _modules_dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modules/dashboard/dashboard.module */ 47117);
/* harmony import */ var _modules_auth_login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modules/auth/login/login.component */ 75453);
/* harmony import */ var _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core/shared/shared.module */ 62657);
/* harmony import */ var _modules_auth_register_register_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modules/auth/register/register.component */ 51805);
/* harmony import */ var _modules_auth_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./modules/auth/reset-password/reset-password.component */ 91025);
/* harmony import */ var _core_permission_guards_feature_guard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/permission/guards/feature.guard */ 16152);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ 46443);
/* harmony import */ var _core_shared_interceptors_auth_interceptor__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/shared/interceptors/auth.interceptor */ 85802);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/platform-browser/animations */ 43835);
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ 48418);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 37580);















class AppModule {
  static {
    this.ɵfac = function AppModule_Factory(t) {
      return new (t || AppModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineNgModule"]({
      type: AppModule,
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent]
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjector"]({
      providers: [_core_permission_guards_feature_guard__WEBPACK_IMPORTED_MODULE_8__.FeatureGuard,
      // {
      //   provide: LocationStrategy,
      //   useClass: HashLocationStrategy
      // },
      {
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HTTP_INTERCEPTORS,
        useClass: _core_shared_interceptors_auth_interceptor__WEBPACK_IMPORTED_MODULE_9__.AuthInterceptor,
        multi: true
      }],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_12__.BrowserModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpClientModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _core_default_layout_default_layout_module__WEBPACK_IMPORTED_MODULE_2__.DefaultLayoutModule, _modules_dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_3__.DashboardModule, _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__.SharedAppModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__.BrowserAnimationsModule, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__.NgbModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent, _modules_auth_login_login_component__WEBPACK_IMPORTED_MODULE_4__.LoginComponent, _modules_auth_register_register_component__WEBPACK_IMPORTED_MODULE_6__.RegisterComponent, _modules_auth_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_7__.ResetPasswordComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_12__.BrowserModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_11__.HttpClientModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _core_default_layout_default_layout_module__WEBPACK_IMPORTED_MODULE_2__.DefaultLayoutModule, _modules_dashboard_dashboard_module__WEBPACK_IMPORTED_MODULE_3__.DashboardModule, _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__.SharedAppModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__.BrowserAnimationsModule, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__.NgbModule]
  });
})();

/***/ }),

/***/ 62017:
/*!*********************************************!*\
  !*** ./src/app/core/default-layout/_nav.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   navItems: () => (/* binding */ navItems)
/* harmony export */ });
const navItems = [{
  name: 'Dashboard',
  url: '/dashboard',
  iconComponent: {
    name: 'nav-icon fas fa-tachometer-alt'
  }
}, {
  name: 'Users',
  url: '/users',
  iconComponent: {
    name: 'nav-icon fas fa-regular fa-user'
  }
}];

/***/ }),

/***/ 29969:
/*!**********************************************************************************!*\
  !*** ./src/app/core/default-layout/control-sidebar/control-sidebar.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ControlSidebarComponent: () => (/* binding */ ControlSidebarComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37580);

class ControlSidebarComponent {
  constructor() {}
  ngOnInit() {}
  static {
    this.ɵfac = function ControlSidebarComponent_Factory(t) {
      return new (t || ControlSidebarComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ControlSidebarComponent,
      selectors: [["app-control-sidebar"]],
      decls: 1,
      vars: 0,
      consts: [[1, "control-sidebar", "control-sidebar-dark"]],
      template: function ControlSidebarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "aside", 0);
        }
      },
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 35604:
/*!*******************************************************************************!*\
  !*** ./src/app/core/default-layout/control-sidebar/control-sidebar.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ControlSidebarModule: () => (/* binding */ ControlSidebarModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _control_sidebar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./control-sidebar.component */ 29969);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);




class ControlSidebarModule {
  static {
    this.ɵfac = function ControlSidebarModule_Factory(t) {
      return new (t || ControlSidebarModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: ControlSidebarModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ControlSidebarModule, {
    declarations: [_control_sidebar_component__WEBPACK_IMPORTED_MODULE_0__.ControlSidebarComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_control_sidebar_component__WEBPACK_IMPORTED_MODULE_0__.ControlSidebarComponent]
  });
})();

/***/ }),

/***/ 85704:
/*!*****************************************************************!*\
  !*** ./src/app/core/default-layout/default-layout.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DefaultLayoutComponent: () => (/* binding */ DefaultLayoutComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var src_app_services_theme_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/theme.service */ 70487);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _main_header_main_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main-header/main-header.component */ 68089);
/* harmony import */ var _main_sidebar_main_sidebar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./main-sidebar/main-sidebar.component */ 39295);
/* harmony import */ var _control_sidebar_control_sidebar_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./control-sidebar/control-sidebar.component */ 29969);
/* harmony import */ var _main_footer_main_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./main-footer/main-footer.component */ 46729);








class DefaultLayoutComponent {
  constructor() {
    this.themeService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.inject)(src_app_services_theme_service__WEBPACK_IMPORTED_MODULE_0__.ThemeService);
  }
  static {
    this.ɵfac = function DefaultLayoutComponent_Factory(t) {
      return new (t || DefaultLayoutComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
      type: DefaultLayoutComponent,
      selectors: [["app-dashboard"]],
      decls: 6,
      vars: 2,
      consts: [["id", "main-content", "tabindex", "-1", 1, "content-wrapper"]],
      template: function DefaultLayoutComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-main-header")(1, "app-main-sidebar");
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "router-outlet");
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "app-control-sidebar")(5, "app-main-footer");
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx.themeService.currentTheme() === "dark" ? "dark-component" : "light-component");
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterOutlet, _main_header_main_header_component__WEBPACK_IMPORTED_MODULE_1__.MainHeaderComponent, _main_sidebar_main_sidebar_component__WEBPACK_IMPORTED_MODULE_2__.MainSidebarComponent, _control_sidebar_control_sidebar_component__WEBPACK_IMPORTED_MODULE_3__.ControlSidebarComponent, _main_footer_main_footer_component__WEBPACK_IMPORTED_MODULE_4__.MainFooterComponent],
      styles: ["[_nghost-%COMP%]   .ng-scrollbar[_ngcontent-%COMP%] {\n  --scrollbar-thumb-color: var(--cui-border-color, #999);\n  --scrollbar-track-color: var(--cui-body-color, #fff);\n  --scrollbar-hover-size: calc(var(--scrollbar-size) * 1.5);\n}\n\n.dark-theme[_nghost-%COMP%]   .ng-scrollbar[_ngcontent-%COMP%], .dark-theme   [_nghost-%COMP%]   .ng-scrollbar[_ngcontent-%COMP%] {\n  --scrollbar-thumb-color: var(--cui-gray-600, #444);\n  --scrollbar-thumb-hover-color: var(--cui-gray-400, #999);\n  --scrollbar-track-color: var(--cui-body-bg, #fff);\n  --scrollbar-hover-size: calc(var(--scrollbar-size) * 1.5);\n}\n\n.emme-project[_ngcontent-%COMP%] {\n  width: 190px;\n  height: 35px;\n  font-size: 26px;\n  margin-left: 40px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n\n.emme-project[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: red;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9kZWZhdWx0LWxheW91dC9kZWZhdWx0LWxheW91dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLHNEQUFBO0VBQ0Esb0RBQUE7RUFDQSx5REFBQTtBQUFKOztBQUlFO0VBQ0Usa0RBQUE7RUFDQSx3REFBQTtFQUNBLGlEQUFBO0VBQ0EseURBQUE7QUFESjs7QUFLQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUZGOztBQUtBO0VBQ0ksVUFBQTtBQUZKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICAubmctc2Nyb2xsYmFyIHtcbiAgICAtLXNjcm9sbGJhci10aHVtYi1jb2xvcjogdmFyKC0tY3VpLWJvcmRlci1jb2xvciwgIzk5OSk7XG4gICAgLS1zY3JvbGxiYXItdHJhY2stY29sb3I6IHZhcigtLWN1aS1ib2R5LWNvbG9yLCAjZmZmKTtcbiAgICAtLXNjcm9sbGJhci1ob3Zlci1zaXplOiBjYWxjKHZhcigtLXNjcm9sbGJhci1zaXplKSAqIDEuNSk7XG4gIH1cbn1cbjpob3N0LWNvbnRleHQoLmRhcmstdGhlbWUpIHtcbiAgLm5nLXNjcm9sbGJhciB7XG4gICAgLS1zY3JvbGxiYXItdGh1bWItY29sb3I6IHZhcigtLWN1aS1ncmF5LTYwMCwgIzQ0NCk7XG4gICAgLS1zY3JvbGxiYXItdGh1bWItaG92ZXItY29sb3I6IHZhcigtLWN1aS1ncmF5LTQwMCwgIzk5OSk7XG4gICAgLS1zY3JvbGxiYXItdHJhY2stY29sb3I6IHZhcigtLWN1aS1ib2R5LWJnLCAjZmZmKTtcbiAgICAtLXNjcm9sbGJhci1ob3Zlci1zaXplOiBjYWxjKHZhcigtLXNjcm9sbGJhci1zaXplKSAqIDEuNSk7XG4gIH1cbn1cblxuLmVtbWUtcHJvamVjdHtcbiAgd2lkdGg6IDE5MHB4O1xuICBoZWlnaHQ6IDM1cHg7XG4gIGZvbnQtc2l6ZTogMjZweDtcbiAgbWFyZ2luLWxlZnQ6IDQwcHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gXG59XG4uZW1tZS1wcm9qZWN0ICBzcGFue1xuICAgIGNvbG9yOiByZWQ7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 8647:
/*!**************************************************************!*\
  !*** ./src/app/core/default-layout/default-layout.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DefaultLayoutModule: () => (/* binding */ DefaultLayoutModule)
/* harmony export */ });
/* harmony import */ var _default_layout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./default-layout.component */ 85704);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _main_header_main_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main-header/main-header.module */ 59116);
/* harmony import */ var _main_sidebar_main_sidebar_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./main-sidebar/main-sidebar.module */ 18558);
/* harmony import */ var _main_footer_main_footer_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./main-footer/main-footer.module */ 76700);
/* harmony import */ var _control_sidebar_control_sidebar_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./control-sidebar/control-sidebar.module */ 35604);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37580);








class DefaultLayoutModule {
  static {
    this.ɵfac = function DefaultLayoutModule_Factory(t) {
      return new (t || DefaultLayoutModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
      type: DefaultLayoutModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _main_header_main_header_module__WEBPACK_IMPORTED_MODULE_1__.MainHeaderModule, _main_sidebar_main_sidebar_module__WEBPACK_IMPORTED_MODULE_2__.MainSidebarModule, _control_sidebar_control_sidebar_module__WEBPACK_IMPORTED_MODULE_4__.ControlSidebarModule, _main_footer_main_footer_module__WEBPACK_IMPORTED_MODULE_3__.MainFooterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](DefaultLayoutModule, {
    declarations: [_default_layout_component__WEBPACK_IMPORTED_MODULE_0__.DefaultLayoutComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _main_header_main_header_module__WEBPACK_IMPORTED_MODULE_1__.MainHeaderModule, _main_sidebar_main_sidebar_module__WEBPACK_IMPORTED_MODULE_2__.MainSidebarModule, _control_sidebar_control_sidebar_module__WEBPACK_IMPORTED_MODULE_4__.ControlSidebarModule, _main_footer_main_footer_module__WEBPACK_IMPORTED_MODULE_3__.MainFooterModule],
    exports: [_default_layout_component__WEBPACK_IMPORTED_MODULE_0__.DefaultLayoutComponent]
  });
})();

/***/ }),

/***/ 46729:
/*!**************************************************************************!*\
  !*** ./src/app/core/default-layout/main-footer/main-footer.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainFooterComponent: () => (/* binding */ MainFooterComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37580);

class MainFooterComponent {
  constructor() {}
  ngOnInit() {}
  static {
    this.ɵfac = function MainFooterComponent_Factory(t) {
      return new (t || MainFooterComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: MainFooterComponent,
      selectors: [["app-main-footer"]],
      decls: 11,
      vars: 0,
      consts: [[1, "main-footer"], [1, "text-primary"], [1, "float-right", "d-none", "d-sm-inline-block"]],
      template: function MainFooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "footer", 0)(1, "strong");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Copyright \u00A9 2020-2025 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "DreamerPeople");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, ".");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " All rights reserved. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 2)(8, "b");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Version");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " 3.2.0 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
      },
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 76700:
/*!***********************************************************************!*\
  !*** ./src/app/core/default-layout/main-footer/main-footer.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainFooterModule: () => (/* binding */ MainFooterModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _main_footer_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-footer.component */ 46729);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);




class MainFooterModule {
  static {
    this.ɵfac = function MainFooterModule_Factory(t) {
      return new (t || MainFooterModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: MainFooterModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](MainFooterModule, {
    declarations: [_main_footer_component__WEBPACK_IMPORTED_MODULE_0__.MainFooterComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_main_footer_component__WEBPACK_IMPORTED_MODULE_0__.MainFooterComponent]
  });
})();

/***/ }),

/***/ 68089:
/*!**************************************************************************!*\
  !*** ./src/app/core/default-layout/main-header/main-header.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainHeaderComponent: () => (/* binding */ MainHeaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var src_app_services_theme_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/theme.service */ 70487);
/* harmony import */ var _modules_common_theme_toggle_theme_toggle_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../modules/common/theme-toggle/theme-toggle.component */ 51764);




class MainHeaderComponent {
  constructor() {
    this.themeService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.inject)(src_app_services_theme_service__WEBPACK_IMPORTED_MODULE_0__.ThemeService);
  }
  ngOnInit() {}
  static {
    this.ɵfac = function MainHeaderComponent_Factory(t) {
      return new (t || MainHeaderComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: MainHeaderComponent,
      selectors: [["app-main-header"]],
      decls: 110,
      vars: 2,
      consts: [[1, "main-header", "navbar", "navbar-expand", "navbar-white", "navbar-light"], [1, "navbar-nav"], [1, "nav-item"], ["data-widget", "pushmenu", "href", "#", "role", "button", 1, "nav-link"], [1, "fas", "fa-bars"], [1, "nav-item", "d-none", "d-sm-inline-block"], ["href", "index3.html", 1, "nav-link"], ["href", "#", 1, "nav-link"], [1, "navbar-nav", "ml-auto"], ["data-widget", "navbar-search", "href", "#", "role", "button", 1, "nav-link"], [1, "fas", "fa-search"], [1, "navbar-search-block"], [1, "form-inline"], [1, "input-group", "input-group-sm"], ["type", "search", "placeholder", "Search", "aria-label", "Search", 1, "form-control", "form-control-navbar"], [1, "input-group-append"], ["type", "submit", 1, "btn", "btn-navbar"], ["type", "button", "data-widget", "navbar-search", 1, "btn", "btn-navbar"], [1, "fas", "fa-times"], [1, "nav-item", "dropdown"], ["data-toggle", "dropdown", "href", "#", 1, "nav-link"], [1, "far", "fa-comments"], [1, "badge", "badge-danger", "navbar-badge"], [1, "dropdown-menu", "dropdown-menu-lg", "dropdown-menu-right"], ["href", "#", 1, "dropdown-item"], [1, "media"], ["src", "assets/dist/img/user1-128x128.jpg", "alt", "User Avatar", 1, "img-size-50", "mr-3", "img-circle"], [1, "media-body"], [1, "dropdown-item-title"], [1, "float-right", "text-sm", "text-danger"], [1, "fas", "fa-star"], [1, "text-sm"], [1, "text-sm", "text-muted"], [1, "far", "fa-clock", "mr-1"], [1, "dropdown-divider"], ["src", "assets/dist/img/user8-128x128.jpg", "alt", "User Avatar", 1, "img-size-50", "img-circle", "mr-3"], [1, "float-right", "text-sm", "text-muted"], ["src", "assets/dist/img/user3-128x128.jpg", "alt", "User Avatar", 1, "img-size-50", "img-circle", "mr-3"], [1, "float-right", "text-sm", "text-warning"], ["href", "#", 1, "dropdown-item", "dropdown-footer"], [1, "far", "fa-bell"], [1, "badge", "badge-warning", "navbar-badge"], [1, "dropdown-item", "dropdown-header"], [1, "fas", "fa-envelope", "mr-2"], [1, "float-right", "text-muted", "text-sm"], [1, "fas", "fa-users", "mr-2"], [1, "fas", "fa-file", "mr-2"], ["data-widget", "fullscreen", "href", "#", "role", "button", 1, "nav-link"], [1, "fas", "fa-expand-arrows-alt"], ["data-widget", "control-sidebar", "data-controlsidebar-slide", "true", "href", "#", "role", "button", 1, "nav-link"], [1, "fas", "fa-th-large"]],
      template: function MainHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "nav", 0)(1, "ul", 1)(2, "li", 2)(3, "a", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "i", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "li", 5)(6, "a", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, "Home");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "li", 5)(9, "a", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Contact");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "app-theme-toggle");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "ul", 8)(13, "li", 2)(14, "a", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "i", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 11)(17, "form", 12)(18, "div", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](19, "input", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 15)(21, "button", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](22, "i", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "button", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](24, "i", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "li", 19)(26, "a", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](27, "i", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](28, "span", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](29, "3");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "div", 23)(31, "a", 24)(32, "div", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](33, "img", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "div", 27)(35, "h3", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](36, " Brad Diesel ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](37, "span", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](38, "i", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](39, "p", 31);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](40, "Call me whenever you can...");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "p", 32);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](42, "i", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](43, " 4 Hours Ago");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](44, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](45, "a", 24)(46, "div", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](47, "img", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](48, "div", 27)(49, "h3", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](50, " John Pierce ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](51, "span", 36);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](52, "i", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](53, "p", 31);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](54, "I got your message bro");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](55, "p", 32);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](56, "i", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](57, " 4 Hours Ago");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](58, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](59, "a", 24)(60, "div", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](61, "img", 37);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](62, "div", 27)(63, "h3", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](64, " Nora Silvester ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](65, "span", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](66, "i", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](67, "p", 31);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](68, "The subject goes here");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](69, "p", 32);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](70, "i", 33);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](71, " 4 Hours Ago");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](72, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](73, "a", 39);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](74, "See All Messages");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](75, "li", 19)(76, "a", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](77, "i", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](78, "span", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](79, "15");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](80, "div", 23)(81, "span", 42);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](82, "15 Notifications");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](83, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](84, "a", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](85, "i", 43);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](86, " 4 new messages ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](87, "span", 44);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](88, "3 mins");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](89, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](90, "a", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](91, "i", 45);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](92, " 8 friend requests ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](93, "span", 44);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](94, "12 hours");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](95, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](96, "a", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](97, "i", 46);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](98, " 3 new reports ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](99, "span", 44);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](100, "2 days");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](101, "div", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](102, "a", 39);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](103, "See All Notifications");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](104, "li", 2)(105, "a", 47);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](106, "i", 48);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](107, "li", 2)(108, "a", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](109, "i", 50);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassMap"](ctx.themeService.currentTheme() === "dark" ? "dark-component" : "light-component");
        }
      },
      dependencies: [_modules_common_theme_toggle_theme_toggle_component__WEBPACK_IMPORTED_MODULE_1__.ThemeToggleComponent],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 59116:
/*!***********************************************************************!*\
  !*** ./src/app/core/default-layout/main-header/main-header.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainHeaderModule: () => (/* binding */ MainHeaderModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _main_header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-header.component */ 68089);
/* harmony import */ var src_app_modules_common_theme_toggle_theme_toggle_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/modules/common/theme-toggle/theme-toggle.module */ 78771);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);





class MainHeaderModule {
  static {
    this.ɵfac = function MainHeaderModule_Factory(t) {
      return new (t || MainHeaderModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
      type: MainHeaderModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule, src_app_modules_common_theme_toggle_theme_toggle_module__WEBPACK_IMPORTED_MODULE_1__.ThemeToggleModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](MainHeaderModule, {
    declarations: [_main_header_component__WEBPACK_IMPORTED_MODULE_0__.MainHeaderComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule, src_app_modules_common_theme_toggle_theme_toggle_module__WEBPACK_IMPORTED_MODULE_1__.ThemeToggleModule],
    exports: [_main_header_component__WEBPACK_IMPORTED_MODULE_0__.MainHeaderComponent]
  });
})();

/***/ }),

/***/ 39295:
/*!****************************************************************************!*\
  !*** ./src/app/core/default-layout/main-sidebar/main-sidebar.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainSidebarComponent: () => (/* binding */ MainSidebarComponent)
/* harmony export */ });
/* harmony import */ var _nav__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_nav */ 62017);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/icon */ 93840);




const _c0 = () => ["/product"];
const _c1 = () => ["active"];
const _c2 = () => ["/category"];
const _c3 = () => ["/order-dashboard"];
const _c4 = () => ["/data-board"];
const _c5 = () => ["/json-editor"];
const _c6 = () => ["/multi-file-uploader"];
const _c7 = () => ["/multi-file-uploader2"];
class MainSidebarComponent {
  constructor() {
    this.navItems = _nav__WEBPACK_IMPORTED_MODULE_0__.navItems;
  }
  ngOnInit() {}
  static {
    this.ɵfac = function MainSidebarComponent_Factory(t) {
      return new (t || MainSidebarComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: MainSidebarComponent,
      selectors: [["app-main-sidebar"]],
      decls: 56,
      vars: 28,
      consts: [[1, "main-sidebar", "sidebar-dark-primary", "elevation-4"], ["href", "index3.html", 1, "brand-link"], ["src", "assets/dist/img/AdminLTELogo.png", "alt", "AdminLTE Logo", 1, "brand-image", "img-circle", "elevation-3", 2, "opacity", "0.8"], [1, "brand-text", "font-weight-light"], [1, "sidebar"], [1, "user-panel", "mt-3", "pb-3", "mb-3", "d-flex", "align-items-end"], [1, "image"], [1, "img-circle", "elevation-2", "bg-white"], [1, "info"], ["href", "#", 1, "d-block"], [1, "form-inline"], ["data-widget", "sidebar-search", 1, "input-group"], ["type", "search", "placeholder", "Search", "aria-label", "Search", 1, "form-control", "form-control-sidebar"], [1, "input-group-append"], [1, "btn", "btn-sidebar"], [1, "fas", "fa-search", "fa-fw"], [1, "mt-2"], ["data-widget", "treeview", "role", "menu", "data-accordion", "false", 1, "nav", "nav-pills", "nav-sidebar", "flex-column"], [1, "nav-item"], [1, "nav-link", 3, "routerLink", "routerLinkActive"], [1, "nav-icon", "fas", "fa-box"], [1, "nav-icon", "fas", "fa-server"]],
      template: function MainSidebarComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "aside", 0)(1, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "img", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "span", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Ecommerce");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 4)(6, "div", 5)(7, "div", 6)(8, "mat-icon", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "person");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 8)(11, "a", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "Dreamer People");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 10)(14, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "input", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 13)(17, "button", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](18, "i", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "nav", 16)(20, "ul", 17)(21, "li", 18)(22, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](23, "i", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Product");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "li", 18)(27, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](28, "i", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Category");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "li", 18)(32, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](33, "i", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](35, "Order Dashboard");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "li", 18)(37, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](38, "i", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](39, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](40, "Data Board");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](41, "li", 18)(42, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](43, "i", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](44, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](45, "JSON Editor");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](46, "li", 18)(47, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](48, "i", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](49, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](50, "Multi File Uploader");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](51, "li", 18)(52, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](53, "i", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](54, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](55, "Multi File Uploader2");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](14, _c0))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](15, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](16, _c2))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](17, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](18, _c3))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](19, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](20, _c4))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](21, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](22, _c5))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](23, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](24, _c6))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](25, _c1));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](26, _c7))("routerLinkActive", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](27, _c1));
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterLink, _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterLinkActive, _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIcon],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 18558:
/*!*************************************************************************!*\
  !*** ./src/app/core/default-layout/main-sidebar/main-sidebar.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainSidebarModule: () => (/* binding */ MainSidebarModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _main_sidebar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main-sidebar.component */ 39295);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/icon */ 93840);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);





class MainSidebarModule {
  static {
    this.ɵfac = function MainSidebarModule_Factory(t) {
      return new (t || MainSidebarModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: MainSidebarModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](MainSidebarModule, {
    declarations: [_main_sidebar_component__WEBPACK_IMPORTED_MODULE_0__.MainSidebarComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconModule],
    exports: [_main_sidebar_component__WEBPACK_IMPORTED_MODULE_0__.MainSidebarComponent]
  });
})();

/***/ }),

/***/ 56851:
/*!***************************************************************************!*\
  !*** ./src/app/core/permission/directives/check-permissions.directive.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CheckPermissionsDirective: () => (/* binding */ CheckPermissionsDirective)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var _models_permissions_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../models/permissions.enum */ 10958);
/* harmony import */ var _models_features_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/features.enum */ 49531);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_permission_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/permission.service */ 42609);





class CheckPermissionsDirective {
  constructor(permissionService, templateRef, viewContainer) {
    this.permissionService = permissionService;
    this.templateRef = templateRef;
    this.viewContainer = viewContainer;
    this.appCheckPermissions = _models_permissions_enum__WEBPACK_IMPORTED_MODULE_0__.Permission.None;
    this.appCheckPermissionsFeature = _models_features_enum__WEBPACK_IMPORTED_MODULE_1__.Features.Spa_Inventory;
    this.onDestroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.Subject();
  }
  ngOnInit() {
    let userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
    // Fetch All user Permissions and verify user have access or not
    if (!!userInfo && this.permissionService.checkPermissionForDirective(userInfo, this.appCheckPermissions)) {
      this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }
  ngOnDestroy() {
    this.onDestroy$.next(true);
    this.onDestroy$.unsubscribe();
  }
  static {
    this.ɵfac = function CheckPermissionsDirective_Factory(t) {
      return new (t || CheckPermissionsDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_permission_service__WEBPACK_IMPORTED_MODULE_2__.PermissionService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.TemplateRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewContainerRef));
    };
  }
  static {
    this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineDirective"]({
      type: CheckPermissionsDirective,
      selectors: [["", "appCheckPermissions", ""]],
      inputs: {
        appCheckPermissions: "appCheckPermissions",
        appCheckPermissionsFeature: "appCheckPermissionsFeature"
      }
    });
  }
}

/***/ }),

/***/ 16152:
/*!*********************************************************!*\
  !*** ./src/app/core/permission/guards/feature.guard.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FeatureGuard: () => (/* binding */ FeatureGuard)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _services_permission_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/permission.service */ 42609);



class FeatureGuard {
  constructor(router, permissionService) {
    this.router = router;
    this.permissionService = permissionService;
  }
  ngOnInit() {}
  canActivate(route, state) {
    let userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (!!userInfo && this.permissionService.checkPermission(userInfo, route.data.feature, route.data.permission, state.url)) {
      return true;
    } else {
      this.router.navigate(['/login']);
    }
  }
  static {
    this.ɵfac = function FeatureGuard_Factory(t) {
      return new (t || FeatureGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_services_permission_service__WEBPACK_IMPORTED_MODULE_0__.PermissionService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: FeatureGuard,
      factory: FeatureGuard.ɵfac
    });
  }
}

/***/ }),

/***/ 49531:
/*!*********************************************************!*\
  !*** ./src/app/core/permission/models/features.enum.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Features: () => (/* binding */ Features)
/* harmony export */ });
var Features;
(function (Features) {
  Features["Spa_Inventory"] = "Spa Inventory";
})(Features || (Features = {}));

/***/ }),

/***/ 10958:
/*!************************************************************!*\
  !*** ./src/app/core/permission/models/permissions.enum.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Permission: () => (/* binding */ Permission)
/* harmony export */ });
var Permission;
(function (Permission) {
  Permission["None"] = "None";
  Permission["View"] = "View";
  Permission["Admin"] = "Admin";
})(Permission || (Permission = {}));

/***/ }),

/***/ 78649:
/*!******************************************************!*\
  !*** ./src/app/core/permission/permission.module.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PermissionModule: () => (/* binding */ PermissionModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _services_permission_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/permission.service */ 42609);
/* harmony import */ var _guards_feature_guard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./guards/feature.guard */ 16152);
/* harmony import */ var _directives_check_permissions_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./directives/check-permissions.directive */ 56851);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37580);





class PermissionModule {
  static {
    this.ɵfac = function PermissionModule_Factory(t) {
      return new (t || PermissionModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
      type: PermissionModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
      providers: [_guards_feature_guard__WEBPACK_IMPORTED_MODULE_1__.FeatureGuard, _services_permission_service__WEBPACK_IMPORTED_MODULE_0__.PermissionService],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](PermissionModule, {
    declarations: [_directives_check_permissions_directive__WEBPACK_IMPORTED_MODULE_2__.CheckPermissionsDirective],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule],
    exports: [_directives_check_permissions_directive__WEBPACK_IMPORTED_MODULE_2__.CheckPermissionsDirective]
  });
})();

/***/ }),

/***/ 42609:
/*!****************************************************************!*\
  !*** ./src/app/core/permission/services/permission.service.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PermissionService: () => (/* binding */ PermissionService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37580);

class PermissionService {
  checkPermission(user, feature, permission, url = null) {
    let allowedUrls = JSON.parse(localStorage.getItem('navItems'));
    if (allowedUrls) {
      const new_url = url.split('?');
      const featurePermission = allowedUrls.find(f => f.url === new_url[0]);
      if (!!featurePermission) {
        return true;
      }
    }
    return false;
  }
  checkPermissionForDirective(user, permission, url = null) {
    const featurePermission = user.userPermissions.find(f => f.permissionCode === permission);
    if (!!featurePermission) {
      return true;
    }
    return false;
  }
  static {
    this.ɵfac = function PermissionService_Factory(t) {
      return new (t || PermissionService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: PermissionService,
      factory: PermissionService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 94403:
/*!**********************************************!*\
  !*** ./src/app/core/shared/alert.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AlertService: () => (/* binding */ AlertService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 75797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _utils_api_handler_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/api-handler.service */ 14090);



class AlertService {
  constructor(http) {
    this.http = http;
    this.spinnerr$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject({});
  }
  getSpinnerObservable() {
    return this.spinnerr$.asObservable();
  }
  requestedStarted(heading, message, type) {
    this.spinnerr$.next({
      status: 'start',
      heading: heading,
      message: message,
      type: type
    });
  }
  requestedEnded() {
    this.spinnerr$.next({
      status: 'stop'
    });
  }
  static {
    this.ɵfac = function AlertService_Factory(t) {
      return new (t || AlertService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_0__.ApiHandlerService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: AlertService,
      factory: AlertService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 41963:
/*!*******************************************************************************!*\
  !*** ./src/app/core/shared/components/confirmation/confirmation.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConfirmationComponent: () => (/* binding */ ConfirmationComponent)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/animations */ 47172);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 60316);




function ConfirmationComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "div", 4)(4, "h4", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Delete Confirmation");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConfirmationComponent_div_0_Template_button_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.closePopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 8)(10, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Are you sure you want to delete?\u2026");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 9)(13, "button", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConfirmationComponent_div_0_Template_button_click_13_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.closePopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, " Close ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConfirmationComponent_div_0_Template_button_click_15_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.action.emit(true));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@fadeInOut", undefined);
  }
}
class ConfirmationComponent {
  constructor() {
    this.visible = true;
    this.action = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  closePopup() {
    this.visible = false;
  }
  static {
    this.ɵfac = function ConfirmationComponent_Factory(t) {
      return new (t || ConfirmationComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ConfirmationComponent,
      selectors: [["app-confirmation"]],
      inputs: {
        visible: "visible"
      },
      outputs: {
        action: "action"
      },
      decls: 1,
      vars: 1,
      consts: [["class", "modal fade show", "aria-modal", "true", "role", "dialog", "style", "padding-right: 17px; display: block;background: rgb(0 0 0 / 30%);", 4, "ngIf"], ["aria-modal", "true", "role", "dialog", 1, "modal", "fade", "show", 2, "padding-right", "17px", "display", "block", "background", "rgb(0 0 0 / 30%)"], [1, "modal-dialog"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["type", "button", 1, "close", 3, "click"], ["aria-hidden", "true"], [1, "modal-body"], [1, "modal-footer", "justify-content-between"], ["type", "button", 1, "btn", "btn-default", 3, "click"], ["type", "button", 1, "btn", "btn-primary", 3, "click"]],
      template: function ConfirmationComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, ConfirmationComponent_div_0_Template, 17, 1, "div", 0);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.visible);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
      data: {
        animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.trigger)('fadeInOut', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.state)('in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.style)({
          opacity: 1,
          transform: 'translateY(0)'
        })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.transition)('void => *', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.style)({
          opacity: 0,
          transform: 'translateY(100%)'
        }), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.animate)(200)]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.transition)('* => void', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.animate)(200, (0,_angular_animations__WEBPACK_IMPORTED_MODULE_2__.style)({
          opacity: 0,
          transform: 'translateY(100%)'
        }))])])]
      }
    });
  }
}

/***/ }),

/***/ 24089:
/*!***********************************************************************************!*\
  !*** ./src/app/core/shared/components/country-company-branch/common.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CommonComponent: () => (/* binding */ CommonComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 75797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_setting_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../services/setting.service */ 40952);
/* harmony import */ var _services_roles_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/roles.service */ 75545);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 60316);







const _c0 = () => [];
function CommonComponent_div_1_c_multi_select_option_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "c-multi-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const option_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", option_r3.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", option_r3.label, " ");
  }
}
function CommonComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 3)(1, "c-multi-select", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("searchValueChange", function CommonComponent_div_1_Template_c_multi_select_searchValueChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.searchValueForCountry$.next($event));
    })("valueChange", function CommonComponent_div_1_Template_c_multi_select_valueChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.getAllCompanyListByCountry($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, CommonComponent_div_1_c_multi_select_option_3_Template, 2, 2, "c-multi-select-option", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Country");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("cFormFloating", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("options", (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 3, ctx_r1.filteredCountries$)) !== null && tmp_2_0 !== undefined ? tmp_2_0 : _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](7, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 5, ctx_r1.filteredCountries$));
  }
}
function CommonComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.formError.errorForCountry);
  }
}
function CommonComponent_div_3_c_multi_select_option_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "c-multi-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const option_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", option_r5.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", option_r5.label, " ");
  }
}
function CommonComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 3)(1, "c-multi-select", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("searchValueChange", function CommonComponent_div_3_Template_c_multi_select_searchValueChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.searchValueForCompany$.next($event));
    })("valueChange", function CommonComponent_div_3_Template_c_multi_select_valueChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.getAllBranchesListByCompany($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, CommonComponent_div_3_c_multi_select_option_3_Template, 2, 2, "c-multi-select-option", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Company");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("cFormFloating", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("options", (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 3, ctx_r1.filteredCompanies$)) !== null && tmp_2_0 !== undefined ? tmp_2_0 : _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](7, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 5, ctx_r1.filteredCompanies$));
  }
}
function CommonComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.formError.errorForCompany);
  }
}
function CommonComponent_div_5_c_multi_select_option_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "c-multi-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const option_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", option_r7.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", option_r7.label, " ");
  }
}
function CommonComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 3)(1, "c-multi-select", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("searchValueChange", function CommonComponent_div_5_Template_c_multi_select_searchValueChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.searchValueForBranch$.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, CommonComponent_div_5_c_multi_select_option_3_Template, 2, 2, "c-multi-select-option", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "label", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Branch");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_4_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("cFormFloating", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("optionsStyle", ctx_r1.multipleBranches)("multiple", ctx_r1.multipleBranches)("options", (tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 5, ctx_r1.filteredBranches$)) !== null && tmp_4_0 !== undefined ? tmp_4_0 : _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](9, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 7, ctx_r1.filteredBranches$));
  }
}
function CommonComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.formError.errorForBranch);
  }
}
class CommonComponent {
  constructor(rootFormGroup, settingService, roleService, viewContainer) {
    this.rootFormGroup = rootFormGroup;
    this.settingService = settingService;
    this.roleService = roleService;
    this.viewContainer = viewContainer;
    this.excludeBranchDropdown = false;
    this.multipleBranches = false;
    this.editFlag = false;
    this.countryList = [];
    this.errors = [];
    this.formError = {};
    this.companyList = [];
    this.branchList = [];
    this.filteredCountries$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    this.searchValueForCountry$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.filteredCompanies$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    this.searchValueForCompany$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.filteredBranches$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    this.searchValueForBranch$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.formGroup = _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup;
    this.userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  }
  ngOnInit() {
    if (this.multipleBranches) {
      this.multipleBranches = 'checkbox';
    } else {
      this.multipleBranches = 'text';
    }
    this.formGroup = this.rootFormGroup.control;
    this.formGroup.get('companyId').disable();
    if (!this.excludeBranchDropdown) {
      this.formGroup.get('branchId').disable();
    }
    if (this.countryList.length > 0) {
      this.setMultiSelectOptions('country');
      if (this.editFlag) {
        this.formGroup.controls['countryId'].setValue([this.formGroup.value.countryId]);
      }
    }
    if (this.userInfo.roleId != 1) {
      this.formGroup.controls['countryId'].setValue(this.userInfo.countryId);
      this.formGroup.controls['companyId'].setValue(this.userInfo.countryId);
      this.getAllBranchesListByCompany(this.formGroup.controls.companyId.value);
    }
  }
  getAllCompanyListByCountry(id) {
    if (!this.editFlag) {
      this.formGroup.patchValue({
        'companyId': 'default'
      });
      if (!this.excludeBranchDropdown) {
        this.formGroup.patchValue({
          'branchId': 'default'
        });
        this.formGroup.get('branchId').disable();
      }
    }
    if (id && id != 'default') {
      this.roleService.getAllCompanyListByCountry(id)?.subscribe(res => {
        if (res.status === 'success') {
          this.companyList = res.data.company;
          this.formGroup.get('companyId').enable();
          this.formGroup.controls['companyId'].setValue([this.formGroup.value.companyId]);
          this.setMultiSelectOptions('company');
        }
      });
    }
  }
  getAllBranchesListByCompany(id) {
    if (!this.editFlag && !this.excludeBranchDropdown) {
      this.formGroup.patchValue({
        'branchId': 'default'
      });
    }
    if (id && id != 'default' && !this.excludeBranchDropdown) {
      this.roleService.getAllBranchesListByCompany(id)?.subscribe(res => {
        if (res.status === 'success') {
          this.branchList = res.data.branch;
          this.formGroup.get('branchId').enable();
          if (this.multipleBranches) {
            this.formGroup.controls['branchId'].setValue(this.formGroup.value.branchId);
          } else {
            this.formGroup.controls['branchId'].setValue([this.formGroup.value.branchId]);
          }
          this.setMultiSelectOptions('branch');
        }
      });
    }
  }
  setMultiSelectOptions(searched) {
    if (searched == 'country') {
      let countries = JSON.parse(JSON.stringify(this.countryList));
      let countryOptions = [];
      countries.forEach(item => {
        let obj = {};
        obj['value'] = item.id;
        obj['label'] = item.countryName;
        countryOptions.push(obj);
      });
      this.filteredCountries$.next([...countryOptions]);
      this.searchValueForCountry$.subscribe(next => {
        const filtered = countryOptions.filter(option => option.label.toLowerCase().startsWith(next.trimStart().toLowerCase()));
        this.filteredCountries$.next([...filtered]);
      });
    } else if (searched == 'company' && this.companyList) {
      let companies = JSON.parse(JSON.stringify(this.companyList));
      let companyOptions = [];
      companies.forEach(item => {
        let obj = {};
        obj['value'] = item.id;
        obj['label'] = item.companyName;
        companyOptions.push(obj);
      });
      this.filteredCompanies$.next([...companyOptions]);
      this.searchValueForCompany$.subscribe(next => {
        const filtered = companyOptions.filter(option => option.label.toLowerCase().startsWith(next.trimStart().toLowerCase()));
        this.filteredCompanies$.next([...filtered]);
      });
    } else if (searched == 'branch' && this.branchList) {
      let branches = JSON.parse(JSON.stringify(this.branchList));
      let branchOptions = [];
      branches.forEach(item => {
        let obj = {};
        obj['value'] = item.id;
        obj['label'] = item.branchName;
        branchOptions.push(obj);
      });
      this.filteredBranches$.next([...branchOptions]);
      this.searchValueForBranch$.subscribe(next => {
        const filtered = branchOptions.filter(option => option.label.toLowerCase().startsWith(next.trimStart().toLowerCase()));
        this.filteredBranches$.next([...filtered]);
      });
    }
  }
  static {
    this.ɵfac = function CommonComponent_Factory(t) {
      return new (t || CommonComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_setting_service__WEBPACK_IMPORTED_MODULE_0__.SettingService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_roles_service__WEBPACK_IMPORTED_MODULE_1__.RolesService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ViewContainerRef));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: CommonComponent,
      selectors: [["app-common"]],
      inputs: {
        excludeBranchDropdown: "excludeBranchDropdown",
        multipleBranches: "multipleBranches",
        editFlag: "editFlag",
        countryList: "countryList",
        errors: "errors",
        formError: "formError"
      },
      decls: 7,
      vars: 7,
      consts: [[3, "formGroup"], ["class", "mb-3", 3, "cFormFloating", 4, "ngIf"], ["class", "invalid_text mb-2", 4, "ngIf"], [1, "mb-3", 3, "cFormFloating"], ["formControlName", "countryId", "selectionType", "text", "optionsStyle", "text", "id", "countryId", "placeholder", "Select Country", "label", "Select Country", "multiple", "false", "search", "external", 1, "mb-3", 3, "searchValueChange", "valueChange", "options"], [3, "value", 4, "ngFor", "ngForOf"], ["cLabel", "", "for", "countryId"], [3, "value"], [1, "invalid_text", "mb-2"], ["formControlName", "companyId", "selectionType", "text", "optionsStyle", "text", "id", "companyId", "placeholder", "Select Company", "label", "Select Company", "multiple", "false", "search", "external", 1, "mb-3", 3, "searchValueChange", "valueChange", "options"], ["formControlName", "branchId", "id", "branchId", "label", "Select Branch", "search", "external", 1, "mb-3", 3, "searchValueChange", "optionsStyle", "multiple", "options"], ["cLabel", "", "for", "branchId"]],
      template: function CommonComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0, 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, CommonComponent_div_1_Template, 7, 8, "div", 1)(2, CommonComponent_div_2_Template, 2, 1, "div", 2)(3, CommonComponent_div_3_Template, 7, 8, "div", 1)(4, CommonComponent_div_4_Template, 2, 1, "div", 2)(5, CommonComponent_div_5_Template, 7, 10, "div", 1)(6, CommonComponent_div_6_Template, 2, 1, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.formGroup);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.countryList.length > 0 && ctx.userInfo.roleId == 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.errors.includes("countryId"));
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.userInfo.roleId == 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.errors.includes("companyId"));
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.excludeBranchDropdown);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.errors.includes("branchId"));
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe],
      styles: [".userHeader[_ngcontent-%COMP%] {\n  padding: 20px 30px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.table_container[_ngcontent-%COMP%] {\n  padding: 0 0;\n  border-radius: 10px;\n  border: 1px solid lightgray;\n  background-color: #fff;\n}\n\n.upload-file-box[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  border: 1px solid #cdcdcd;\n  border-radius: 7px;\n  height: 40px;\n  overflow: hidden;\n}\n\n.upload-file-box[_ngcontent-%COMP%]   .file-label[_ngcontent-%COMP%] {\n  padding-left: 10px;\n}\n\n.upload-file-box[_ngcontent-%COMP%]   .upload-btn[_ngcontent-%COMP%] {\n  color: #3f7bb9;\n  background-color: #eff4ff;\n  height: 100%;\n  padding: 0 10px;\n  display: flex;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY29tcG9uZW50cy9jb3VudHJ5LWNvbXBhbnktYnJhbmNoL2NvbW1vbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFDQTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0Esc0JBQUE7QUFFRjs7QUFBQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFHRjs7QUFEQTtFQUNFLGtCQUFBO0FBSUY7O0FBRkE7RUFDRSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQUtGIiwic291cmNlc0NvbnRlbnQiOlsiLnVzZXJIZWFkZXJ7XG4gIHBhZGRpbmc6IDIwcHggMzBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLnRhYmxlX2NvbnRhaW5lcntcbiAgcGFkZGluZzogMCAwO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG4udXBsb2FkLWZpbGUtYm94IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NkY2RjZDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4udXBsb2FkLWZpbGUtYm94IC5maWxlLWxhYmVsIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuLnVwbG9hZC1maWxlLWJveCAudXBsb2FkLWJ0biB7XG4gIGNvbG9yOiAjM2Y3YmI5O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWZmNGZmO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBhZGRpbmc6IDAgMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 32987:
/*!*******************************************************************!*\
  !*** ./src/app/core/shared/components/loader/loader.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoaderComponent: () => (/* binding */ LoaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37580);


class LoaderComponent {
  constructor() {
    this.visible = false;
    this.action = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  closePopup() {
    this.visible = false;
  }
  static {
    this.ɵfac = function LoaderComponent_Factory(t) {
      return new (t || LoaderComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: LoaderComponent,
      selectors: [["app-loader"]],
      inputs: {
        visible: "visible"
      },
      outputs: {
        action: "action"
      },
      decls: 4,
      vars: 0,
      consts: [[1, "fade", "show", 2, "text-align", "center", "padding-top", "calc(100vh / 2)", "height", "100vh"], [1, "spinner-grow", "spinner-grow-sm"], [1, "m-1"]],
      template: function LoaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Loading...");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        }
      },
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 71596:
/*!***********************************************!*\
  !*** ./src/app/core/shared/global.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalService: () => (/* binding */ GlobalService)
/* harmony export */ });
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/const */ 12549);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/api-handler.service */ 14090);



class GlobalService {
  constructor(http) {
    this.http = http;
  }
  getBrowserDetail(fingerprint) {
    return this.http.requestCall(_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getBrowserDetail, _utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, fingerprint);
  }
  setBrowserDetail(fingerprint, token) {
    let params = "?browserId=" + fingerprint + '&browserToken=' + token;
    return this.http.requestCall(_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.setBrowserDetail, _utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, params);
  }
  static {
    this.ɵfac = function GlobalService_Factory(t) {
      return new (t || GlobalService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__.ApiHandlerService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: GlobalService,
      factory: GlobalService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 85802:
/*!**************************************************************!*\
  !*** ./src/app/core/shared/interceptors/auth.interceptor.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthInterceptor: () => (/* binding */ AuthInterceptor)
/* harmony export */ });
/* harmony import */ var get_browser_fingerprint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! get-browser-fingerprint */ 97879);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 77919);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _global_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../global.service */ 71596);





class AuthInterceptor {
  constructor(router, globalService) {
    this.router = router;
    this.globalService = globalService;
  }
  intercept(req, next) {
    const fingerprint = (0,get_browser_fingerprint__WEBPACK_IMPORTED_MODULE_0__["default"])();
    let accessToken = '';
    if (localStorage.getItem('token')) {
      accessToken = localStorage.getItem('token') || '';
    }
    if (accessToken) {
      req = this.AddBrowserIdAndToken(req, fingerprint, accessToken);
      req.headers.append('Content-Type', 'application/json');
    } else {
      req = this.AddBrowserId(req, fingerprint);
      req.headers.append('Content-Type', 'application/json');
    }
    return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(error => {
      if (error.status == 401 && error.statusText == 'Unauthorized') {
        localStorage.clear();
        window.location.reload();
      } else {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(() => error);
      }
    }));
  }
  AddBrowserIdAndToken(request, fingerprint, token) {
    debugger;
    let userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (!userInfo) {
      userInfo = {
        user_id: null
      };
    }
    return request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        'fingerprint': String(fingerprint),
        'userId': String(userInfo.user_id)
      }
    });
  }
  AddBrowserId(request, fingerprint) {
    return request.clone({
      setHeaders: {
        'fingerprint': String(fingerprint)
      }
    });
  }
  static {
    this.ɵfac = function AuthInterceptor_Factory(t) {
      return new (t || AuthInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_global_service__WEBPACK_IMPORTED_MODULE_1__.GlobalService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
      token: AuthInterceptor,
      factory: AuthInterceptor.ɵfac
    });
  }
}

/***/ }),

/***/ 75545:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/roles.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RolesService: () => (/* binding */ RolesService)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/utils/const */ 12549);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var src_app_core_shared_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/utils/api-handler.service */ 14090);



class RolesService {
  constructor(http) {
    this.http = http;
    this.userInfo = {};
    this.userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  }
  getUserRoles() {
    let params = '?countryId=' + this.userInfo.countryId + '&companyId=' + this.userInfo.companyId + '&roleId=' + this.userInfo.roleId;
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getRoles, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, params);
  }
  getPermissions() {
    let params = '?countryId=' + this.userInfo.countryId + '&companyId=' + this.userInfo.companyId + '&roleId=' + this.userInfo.roleId;
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getPermissions, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, params);
  }
  createUserRoles(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.createRoles, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  updateUserRoles(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.updateRoles, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  deleteUserRoles(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.deleteRoles, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getUserRolesByID(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getRoleByID, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllCoutriesList() {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllCountriesList, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, '');
  }
  getAllCompanyList() {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllCompaniesList, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, '');
  }
  getAllCompanyListByCountry(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllCompaniesListByCountry, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllBranchesListByCompany(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllBranchesListByCompany, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllPermissions() {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getPermissions, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, '');
  }
  getCompanyPermissionsList(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllPermissionsByCompany, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  updatePermission(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.updatePermissions, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  deletePermission(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.deletePermissions, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  assignPermissions(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.assignPermissions, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  unAssignPermission(permissionId) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.unAssignPermission, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, permissionId);
  }
  static {
    this.ɵfac = function RolesService_Factory(t) {
      return new (t || RolesService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](src_app_core_shared_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__.ApiHandlerService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: RolesService,
      factory: RolesService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 40952:
/*!*********************************************************!*\
  !*** ./src/app/core/shared/services/setting.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingService: () => (/* binding */ SettingService)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/utils/const */ 12549);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var src_app_core_shared_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/utils/api-handler.service */ 14090);



class SettingService {
  constructor(http) {
    this.http = http;
    this.userInfo = JSON.parse(localStorage.getItem('userInfo'));
  }
  getAllCoutriesList() {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllCountriesList, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, '');
  }
  getCountryById(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getCountryById, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  createCountry(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.createCountry, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  updateCountry(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.updateCountry, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  deleteCountry(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.deleteCountry, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllCompaniesList() {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllCompaniesList, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, '');
  }
  getCompanyById(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getCompanyById, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllCompaniesListByCountry(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllCompaniesListByCountry, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  createCompany(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.createCompany, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  updateCompany(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.updateCompany, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  deleteCompany(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.deleteCompany, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllBranchesList() {
    let params = '?countryId=' + this.userInfo.countryId + '&companyId=' + this.userInfo.companyId + '&roleId=' + this.userInfo.roleId;
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllBranchesList, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, params);
  }
  getBranchById(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getBranchById, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  getAllBranchesListByCompany(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.getAllBranchesListByCompany, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  createBranch(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.createBranch, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  updateBranch(data) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.updateBranch, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  deleteBranch(id) {
    return this.http.requestCall(src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.deleteBranch, src_app_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET, id);
  }
  static {
    this.ɵfac = function SettingService_Factory(t) {
      return new (t || SettingService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](src_app_core_shared_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__.ApiHandlerService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: SettingService,
      factory: SettingService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 62657:
/*!**********************************************!*\
  !*** ./src/app/core/shared/shared.module.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SharedAppModule: () => (/* binding */ SharedAppModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/confirmation/confirmation.component */ 41963);
/* harmony import */ var _permission_permission_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../permission/permission.module */ 78649);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./alert.service */ 94403);
/* harmony import */ var _components_loader_loader_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/loader/loader.component */ 32987);
/* harmony import */ var _components_country_company_branch_common_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/country-company-branch/common.component */ 24089);
/* harmony import */ var angular_datatables__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-datatables */ 21541);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-select/ng-select */ 62223);
/* harmony import */ var _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @sweetalert2/ngx-sweetalert2 */ 94483);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 37580);











const modules = [_permission_permission_module__WEBPACK_IMPORTED_MODULE_1__.PermissionModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, angular_datatables__WEBPACK_IMPORTED_MODULE_5__.DataTablesModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__.NgSelectModule, _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_8__.SweetAlert2Module];
class SharedAppModule {
  static {
    this.ɵfac = function SharedAppModule_Factory(t) {
      return new (t || SharedAppModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({
      type: SharedAppModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({
      providers: [_alert_service__WEBPACK_IMPORTED_MODULE_2__.AlertService],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule, modules, _permission_permission_module__WEBPACK_IMPORTED_MODULE_1__.PermissionModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, angular_datatables__WEBPACK_IMPORTED_MODULE_5__.DataTablesModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__.NgSelectModule, _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_8__.SweetAlert2Module]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](SharedAppModule, {
    declarations: [_components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_0__.ConfirmationComponent, _components_loader_loader_component__WEBPACK_IMPORTED_MODULE_3__.LoaderComponent, _components_country_company_branch_common_component__WEBPACK_IMPORTED_MODULE_4__.CommonComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule, _permission_permission_module__WEBPACK_IMPORTED_MODULE_1__.PermissionModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, angular_datatables__WEBPACK_IMPORTED_MODULE_5__.DataTablesModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__.NgSelectModule, _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_8__.SweetAlert2Module],
    exports: [_permission_permission_module__WEBPACK_IMPORTED_MODULE_1__.PermissionModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, angular_datatables__WEBPACK_IMPORTED_MODULE_5__.DataTablesModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__.NgSelectModule, _sweetalert2_ngx_sweetalert2__WEBPACK_IMPORTED_MODULE_8__.SweetAlert2Module, _components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_0__.ConfirmationComponent, _components_loader_loader_component__WEBPACK_IMPORTED_MODULE_3__.LoaderComponent, _components_country_company_branch_common_component__WEBPACK_IMPORTED_MODULE_4__.CommonComponent]
  });
})();

/***/ }),

/***/ 96946:
/*!***********************************************!*\
  !*** ./src/app/core/shared/socket.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SocketService: () => (/* binding */ SocketService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 43942);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! socket.io-client */ 98654);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37580);




class SocketService {
  constructor() {
    this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ws_url;
    this.userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (this.userInfo) {
      this.url = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.ws_url}?companyId=${this.userInfo.companyId}&token=${localStorage.getItem('token')}`;
      this.socket = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_1__.io)(this.url);
    }
  }
  emitLoginLogout(user) {
    this.socket.emit(`get-latest-login-logout-${this.userInfo.companyId}`, user);
  }
  geLoginLogout() {
    return rxjs__WEBPACK_IMPORTED_MODULE_2__.Observable.create(observer => {
      this.socket.on(`login-logout-${this.userInfo.companyId}`, data => {
        if (data) {
          observer.next(data);
        } else {
          observer.error('Unable To Reach Server');
        }
      });
      return () => {
        this.socket.disconnect();
      };
    });
  }
  emitUser(user) {
    this.socket.emit(`get-latest-users-${this.userInfo.companyId}`, user);
  }
  getUsers() {
    return rxjs__WEBPACK_IMPORTED_MODULE_2__.Observable.create(observer => {
      this.socket.on(`all-users-${this.userInfo.companyId}`, data => {
        if (data) {
          observer.next(data);
        } else {
          observer.error('Unable To Reach Server');
        }
      });
      return () => {
        this.socket.disconnect();
      };
    });
  }
  static {
    this.ɵfac = function SocketService_Factory(t) {
      return new (t || SocketService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
      token: SocketService,
      factory: SocketService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 14090:
/*!**********************************************************!*\
  !*** ./src/app/core/shared/utils/api-handler.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiHandlerService: () => (/* binding */ ApiHandlerService)
/* harmony export */ });
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./const */ 12549);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 61318);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 46443);




class ApiHandlerService {
  constructor(http) {
    this.http = http;
  }
  requestCall(api, method, params, data) {
    let response;
    ;
    params = params == null ? '' : params;
    switch (method) {
      case _const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.GET:
        if (params == '') {
          response = this.http.get(`${_const__WEBPACK_IMPORTED_MODULE_0__.API_URL}${api}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(err => this.handleError(err, this)));
        } else {
          response = this.http.get(`${_const__WEBPACK_IMPORTED_MODULE_0__.API_URL}${api}${params}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(err => this.handleError(err, this)));
        }
        break;
      case _const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST:
        response = this.http.post(`${_const__WEBPACK_IMPORTED_MODULE_0__.API_URL}${api}${params}`, data).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(err => this.handleError(err, this)));
        break;
      case _const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.PUT:
        response = this.http.put(`${_const__WEBPACK_IMPORTED_MODULE_0__.API_URL}${api}${params}`, data).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(err => this.handleError(err, this)));
        break;
      case _const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.DELETE:
        response = this.http.delete(`${_const__WEBPACK_IMPORTED_MODULE_0__.API_URL}${api}${params}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(err => this.handleError(err, this)));
        break;
      default:
        break;
    }
    return response;
  }
  handleError(err, self) {
    return err;
  }
  static {
    this.ɵfac = function ApiHandlerService_Factory(t) {
      return new (t || ApiHandlerService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: ApiHandlerService,
      factory: ApiHandlerService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 12549:
/*!********************************************!*\
  !*** ./src/app/core/shared/utils/const.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   API_ENDPOINTS: () => (/* binding */ API_ENDPOINTS),
/* harmony export */   API_URL: () => (/* binding */ API_URL),
/* harmony export */   ApiMethod: () => (/* binding */ ApiMethod)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);

const API_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api_url;
var ApiMethod;
(function (ApiMethod) {
  ApiMethod["GET"] = "GET";
  ApiMethod["POST"] = "POST";
  ApiMethod["PUT"] = "PUT";
  ApiMethod["DELETE"] = "DELETE";
  ApiMethod["PATCH"] = "PATCH";
})(ApiMethod || (ApiMethod = {}));
const API_ENDPOINTS = {
  logIn: 'users/login',
  signUp: 'users/signup',
  resetPassword: 'users/resetPassword/',
  forgetPassword: 'users/forgotPassword',
  getBrowserDetail: 'users/getBrowserDetail/',
  setBrowserDetail: 'users/setBrowserDetail',
  users: 'users',
  deleteUser: 'users/deleteUser/',
  editUser: 'users/updateUser',
  createUser: 'users/createUser',
  getRoles: 'roles',
  getPermissions: 'permissions',
  getAllPermissionsByRole: 'permissions/getAllPermissionsByRole',
  getAllPermissionsByCompany: 'permissions/getAllPermissionsByCompany/',
  getPermissionByID: 'permissions/',
  createPermissions: 'permissions/createPermission',
  assignPermissions: 'permissions/assignPermission',
  assignCompanyPermission: 'permissions/assignCompanyPermission',
  updatePermissions: 'permissions/updatePermission',
  deletePermissions: 'permissions/deletePermission/',
  unAssignPermission: 'permissions/unAssignPermission/',
  getRoleByID: 'roles/',
  createRoles: 'roles/createRole',
  updateRoles: 'roles/updateRole',
  deleteRoles: 'roles/deleteRole/',
  getAllCountriesList: 'countries',
  getCountryById: 'countries/',
  createCountry: 'countries/createCountry',
  updateCountry: 'countries/updateCountry',
  deleteCountry: 'countries/deleteCountry/',
  getAllCompaniesList: 'companies',
  getAllCompaniesListByCountry: 'companies/getAllCompaniesByCountry/',
  getCompanyById: 'companies/',
  createCompany: 'companies/createCompany',
  updateCompany: 'companies/updateCompany',
  deleteCompany: 'companies/deleteCompany/',
  getAllBranchesList: 'branches',
  getAllBranchesListByCompany: 'branches/getAllBranchesByCompany/',
  getBranchById: 'branches/',
  createBranch: 'branches/createBranch',
  updateBranch: 'branches/updateBranch',
  deleteBranch: 'branches/deleteBranch/',
  categories: 'categories',
  getCategoryById: 'categories/',
  getNestedCategories: 'categories/nest',
  getAllCategoriesByCountry: 'categories/getAllCategoriesByCountry/',
  getAllCategoriesByCompany: 'categories/getAllCategoriesByCompany/',
  createCategory: 'categories/createCategory',
  editCategory: 'categories/updateCategory',
  deleteCategory: 'categories/deleteCategory/',
  units: 'units',
  getUnitById: 'units/',
  getAllUnitsByCountry: 'units/getAllUnitsByCountry/',
  getAllUnitsByCompany: 'units/getAllUnitsByCompany/',
  createUnit: 'units/createUnit',
  editUnit: 'units/updateUnit',
  deleteUnit: 'units/deleteUnit/',
  manufacturers: 'manufacturers',
  getManufacturerById: 'manufacturers/',
  getAllManufacturersByCountry: 'manufacturers/getAllManufacturersByCountry/',
  getAllManufacturersByCompany: 'manufacturers/getAllManufacturersByCompany/',
  createManufacturer: 'manufacturers/createManufacturer',
  editManufacturer: 'manufacturers/updateManufacturer',
  deleteManufacturer: 'manufacturers/deleteManufacturer/',
  taxClasses: 'taxClasses',
  getTaxClassById: 'taxClasses/',
  getAllTaxClassesByCountry: 'taxClasses/getAllTaxClassesByCountry/',
  getAllTaxClassesByCompany: 'taxClasses/getAllTaxClassesByCompany/',
  createTaxClass: 'taxClasses/createTaxClass',
  editTaxClass: 'taxClasses/updateTaxClass',
  deleteTaxClass: 'taxClasses/deleteTaxClass/',
  taxRates: 'taxRates',
  getTaxRateById: 'taxRates/',
  getAllTaxRatesByCountry: 'taxRates/getAllTaxRatesByCountry/',
  getAllTaxRatesByCompany: 'taxRates/getAllTaxRatesByCompany/',
  createTaxRate: 'taxRates/createTaxRate',
  editTaxRate: 'taxRates/updateTaxRate',
  deleteTaxRate: 'taxRates/deleteTaxRate/',
  productOptions: 'productOptions',
  getProductOptionById: 'productOptions/',
  getAllProductOptionsByCountry: 'productOptions/getAllProductOptionsByCountry/',
  getAllProductOptionsByCompany: 'productOptions/getAllProductOptionsByCompany/',
  createProductOption: 'productOptions/createProductOption',
  editProductOption: 'productOptions/updateProductOption',
  deleteProductOption: 'productOptions/deleteProductOption/',
  productOptionValues: 'productOptionValues',
  getProductOptionValuesById: 'productOptionValues/',
  getAllProductOptionValuesByCountry: 'productOptionValues/getAllProductOptionValuesByCountry/',
  getAllProductOptionValuesByCompany: 'productOptionValues/getAllProductOptionValuesByCompany/',
  createProductOptionValue: 'productOptionValues/createProductOptionValue',
  editProductOptionValue: 'productOptionValues/updateProductOptionValue',
  deleteProductOptionValue: 'productOptionValues/deleteProductOptionValue/',
  products: 'products',
  getProductById: 'products/',
  getAllProductsByCountry: 'products/getAllProductsByCountry/',
  getAllProductsByCompany: 'products/getAllProductsByCompany/',
  createProduct: 'products/createProduct',
  editProduct: 'products/updateProduct',
  updateProductImages: 'products/updateProductImages',
  updateProductInfo: 'products/updateProductInfo',
  deleteProduct: 'products/deleteProduct/',
  deleteProductImage: 'products/deleteProductImage/',
  createInventory: 'products/createInventory',
  banners: 'banners',
  getBannerById: 'banners/',
  getAllBannersByCompany: 'banners/getAllBannersByCompany/',
  createBanner: 'banners/createBanner',
  editBanner: 'banners/updateBanner',
  deleteBanner: 'banners/deleteBanner/',
  landingPageCategories: 'landingPageCategories',
  getLandingPageCategoryById: 'landingPageCategories/',
  getAllLandingPageCategoriesByCompany: 'landingPageCategories/getAllLandingPageCategoriesByCompany/',
  createLandingPageCategory: 'landingPageCategories/createLandingPageCategory',
  editLandingPageCategory: 'landingPageCategories/updateLandingPageCategory',
  deleteLandingPageCategory: 'landingPageCategories/deleteLandingPageCategory/',
  brands: 'brands',
  getBrandById: 'brands/',
  getAllBrandsByCompany: 'brands/getAllBrandsByCompany/',
  createBrand: 'brands/createBrand',
  editBrand: 'brands/updateBrand',
  deleteBrand: 'brands/deleteBrand/',
  generalSettings: 'generalSettings',
  getGeneralSettingById: 'generalSettings/',
  getAllGeneralSettingsByCompany: 'generalSettings/getAllGeneralSettingsByCompany/',
  createGeneralSetting: 'generalSettings/createGeneralSetting',
  editGeneralSetting: 'generalSettings/updateGeneralSetting',
  deleteGeneralSetting: 'generalSettings/deleteGeneralSetting/',
  orders: 'orders',
  getOrderById: 'orders/',
  getAllOrdersByCountry: 'orders/getAllOrdersByCountry/',
  getAllOrdersByCompany: 'orders/getAllOrdersByCompany/',
  createOrder: 'orders/createOrder',
  editOrder: 'orders/updateOrder',
  deleteOrder: 'orders/deleteOrder/'
};

/***/ }),

/***/ 75453:
/*!*******************************************************!*\
  !*** ./src/app/modules/auth/login/login.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoginComponent: () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var src_app_core_default_layout_nav__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/default-layout/_nav */ 62017);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/auth.service */ 73769);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var src_app_core_shared_socket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/socket.service */ 96946);







class LoginComponent {
  constructor(authService, router, socket) {
    this.authService = authService;
    this.router = router;
    this.socket = socket;
    this.navItems = src_app_core_default_layout_nav__WEBPACK_IMPORTED_MODULE_0__.navItems;
    this.loginForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]),
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required])
    });
    this.isError = false;
  }
  onSingIn() {
    this.router.navigate(['/dashboard']);
  }
  moveToForgetPassword() {
    this.router.navigate(['reset-password']);
  }
  static {
    this.ɵfac = function LoginComponent_Factory(t) {
      return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_socket_service__WEBPACK_IMPORTED_MODULE_2__.SocketService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: LoginComponent,
      selectors: [["app-login"]],
      decls: 46,
      vars: 2,
      consts: [[1, "hold-transition", "login-page"], [1, "login-box"], [1, "login-logo"], ["href", "javascript:void(0)"], [1, "card"], [1, "card-body", "login-card-body"], [1, "login-box-msg"], [3, "ngSubmit", "formGroup"], [1, "input-group", "mb-3"], ["type", "email", "id", "email", "formControlName", "email", "placeholder", "Email", 1, "form-control"], [1, "input-group-append"], [1, "input-group-text"], [1, "fas", "fa-envelope"], ["type", "password", "id", "password", "formControlName", "password", "placeholder", "Password", 1, "form-control"], [1, "fas", "fa-lock"], [1, "row"], [1, "col-8"], [1, "icheck-primary"], ["type", "checkbox", "id", "remember"], ["for", "remember"], [1, "col-4"], ["type", "submit", "id", "login-btn", 1, "btn", "btn-primary", "btn-block", 3, "disabled"], [1, "social-auth-links", "text-center", "mb-3"], ["href", "#", 1, "btn", "btn-block", "btn-primary"], [1, "fab", "fa-facebook", "mr-2"], ["href", "#", 1, "btn", "btn-block", "btn-danger"], [1, "fab", "fa-google-plus", "mr-2"], [1, "mb-1"], [3, "click"], [1, "mb-0"], ["href", "javascript:void(0)", 1, "text-center"]],
      template: function LoginComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "a", 3)(4, "b");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Admin");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, "LTE");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 4)(8, "div", 5)(9, "p", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, "Sign in to start your session");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "form", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngSubmit", function LoginComponent_Template_form_ngSubmit_11_listener() {
            return ctx.onSingIn();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 10)(15, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](16, "span", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 10)(20, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](21, "span", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "div", 15)(23, "div", 16)(24, "div", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "input", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "label", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](27, " Remember Me ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "div", 20)(29, "button", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, "Sign In");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "div", 22)(32, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](33, "- OR -");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "a", 23);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](35, "i", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](36, " Sign in using Facebook ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "a", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](38, "i", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, " Sign in using Google+ ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "p", 27)(41, "a", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function LoginComponent_Template_a_click_41_listener() {
            return ctx.moveToForgetPassword();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](42, "I forgot my password");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](43, "p", 29)(44, "a", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](45, "Register a new membership");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx.loginForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx.loginForm.valid);
        }
      },
      dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 51805:
/*!*************************************************************!*\
  !*** ./src/app/modules/auth/register/register.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RegisterComponent: () => (/* binding */ RegisterComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/auth.service */ 73769);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 95072);





const _c0 = () => ["/login"];
class RegisterComponent {
  constructor(authService, router) {
    this.authService = authService;
    this.router = router;
    this.signupForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]),
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]),
      password_confirmation: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]),
      username: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]),
      phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required])
    });
    this.isError = false;
    this.passwordError = false;
    this.serverError = false;
  }
  onSingUp() {
    this.serverError = false;
    if (!this.validForm()) {
      return;
    }
    this.authService.signUp(this.signupForm.value)?.subscribe(res => {
      if (res.status === 'success') {
        this.router.navigate(['/login']);
      }
    }, err => {
      this.serverError = true;
    });
  }
  validForm() {
    this.isError = false;
    this.passwordError = false;
    if (!this.signupForm.value.email || !this.signupForm.value.username || !this.signupForm.value.phone || !this.signupForm.value.password || !this.signupForm.value.password_confirmation) {
      this.isError = true;
      return false;
    }
    if (this.signupForm.value.password != this.signupForm.value.password_confirmation) {
      this.passwordError = true;
      return false;
    }
    return true;
  }
  static {
    this.ɵfac = function RegisterComponent_Factory(t) {
      return new (t || RegisterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: RegisterComponent,
      selectors: [["app-register"]],
      decls: 54,
      vars: 4,
      consts: [[1, "hold-transition", "register-page"], [1, "register-box"], [1, "register-logo"], ["href", "javascript:void(0)"], [1, "card"], [1, "card-body", "register-card-body"], [1, "login-box-msg"], [3, "ngSubmit", "formGroup"], [1, "input-group", "mb-3"], ["type", "text", "formControlName", "username", "placeholder", "Full name", 1, "form-control"], [1, "input-group-append"], [1, "input-group-text"], [1, "fas", "fa-user"], ["type", "email", "formControlName", "email", "placeholder", "Email", 1, "form-control"], [1, "fas", "fa-envelope"], ["type", "password", "formControlName", "password", "placeholder", "Password", 1, "form-control"], [1, "fas", "fa-lock"], ["type", "password", "formControlName", "password_confirmation", "placeholder", "Retype password", 1, "form-control"], [1, "row"], [1, "col-8"], [1, "icheck-primary"], ["type", "checkbox", "id", "agreeTerms", "name", "terms", "value", "agree"], ["for", "agreeTerms"], ["href", "#"], [1, "col-4"], ["type", "submit", 1, "btn", "btn-primary", "btn-block", 3, "disabled"], [1, "social-auth-links", "text-center"], ["href", "#", 1, "btn", "btn-block", "btn-primary"], [1, "fab", "fa-facebook", "mr-2"], ["href", "#", 1, "btn", "btn-block", "btn-danger"], [1, "fab", "fa-google-plus", "mr-2"], [1, "text-center", 3, "routerLink"]],
      template: function RegisterComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "a", 3)(4, "b");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5, "Admin");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "LTE");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 4)(8, "div", 5)(9, "p", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Register a new membership");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "form", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngSubmit", function RegisterComponent_Template_form_ngSubmit_11_listener() {
            return ctx.onSingUp();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](13, "input", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 10)(15, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](16, "span", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](18, "input", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 10)(20, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "span", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](23, "input", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "div", 10)(25, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](26, "span", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](28, "input", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "div", 10)(30, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](31, "span", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](32, "div", 18)(33, "div", 19)(34, "div", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](35, "input", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "label", 22);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](37, " I agree to the ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "a", 23);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](39, "terms");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "div", 24)(41, "button", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](42, "Register");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](43, "div", 26)(44, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](45, "- OR -");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](46, "a", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](47, "i", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](48, " Sign up using Facebook ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](49, "a", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](50, "i", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](51, " Sign up using Google+ ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](52, "a", 31);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](53, "I already have a membership");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.signupForm);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](30);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", !ctx.signupForm.valid);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](3, _c0));
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControlName],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 91025:
/*!*************************************************************************!*\
  !*** ./src/app/modules/auth/reset-password/reset-password.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResetPasswordComponent: () => (/* binding */ ResetPasswordComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/auth.service */ 73769);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 60316);






const _c0 = () => ["/login"];
const _c1 = () => ["/register"];
function ResetPasswordComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 2)(1, "div", 3)(2, "a", 4)(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Admin");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5, "LTE");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 5)(7, "div", 6)(8, "p", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "You forgot your password? Here you can easily retrieve a new password.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "form", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function ResetPasswordComponent_div_1_Template_form_ngSubmit_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.onEmailScreenClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "input", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 11)(14, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 14)(17, "div", 15)(18, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "Request new password");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "p", 17)(21, "a", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](22, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "p", 19)(24, "a", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Register a new membership");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx_r1.emailForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", !ctx_r1.emailForm.valid || ctx_r1.emailProcessing);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](4, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](5, _c1));
  }
}
function ResetPasswordComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 2)(1, "div", 3)(2, "a", 4)(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Admin");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5, "LTE");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 5)(7, "div", 6)(8, "p", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "You are only one step a way from your new password, recover your password now.");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "form", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function ResetPasswordComponent_div_2_Template_form_ngSubmit_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.onResetPassword());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "input", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 11)(14, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](17, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 11)(19, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](20, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 14)(22, "div", 15)(23, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, "Change password");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "p", 17)(26, "a", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Login");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx_r1.resetPasswordForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", !ctx_r1.resetPasswordForm.valid);
  }
}
class ResetPasswordComponent {
  constructor(activatedRoute, authService, router) {
    this.activatedRoute = activatedRoute;
    this.authService = authService;
    this.router = router;
    this.resetPasswordForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup({
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]),
      password_confirmation: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required])
    });
    this.emailForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup({
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required])
    });
    this.isError = false;
    this.screen = 'emailScreen';
    this.emailProcessing = false;
    this.token = '';
    this.activatedRoute.queryParams.subscribe(queryParams => {
      if (queryParams.token) {
        this.token = queryParams.token;
        this.screen = 'passwordScreen';
      }
    });
  }
  onResetPassword() {
    this.isError = false;
    this.authService.resetPassword(this.resetPasswordForm.value, this.token)?.subscribe(res => {
      if (res.status === 'success') {
        this.router.navigate(['/login']);
      } else {
        this.isError = true;
      }
    }, err => {
      this.isError = true;
      this.successMsg = 'Token is expired';
    });
  }
  onEmailScreenClick() {
    this.isError = false;
    this.emailProcessing = true;
    this.authService.forgetPassword(this.emailForm.value)?.subscribe(res => {
      this.emailProcessing = false;
      if (res.status === 'success') {
        this.successMsg = 'Reset Password Email Has Been Sent To Your Account';
      } else {
        this.isError = true;
        this.successMsg = 'There is Problem in sending email';
      }
    }, err => {
      this.isError = true;
    });
  }
  static {
    this.ɵfac = function ResetPasswordComponent_Factory(t) {
      return new (t || ResetPasswordComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: ResetPasswordComponent,
      selectors: [["app-reset-password"]],
      decls: 3,
      vars: 2,
      consts: [[1, "hold-transition", "login-page"], ["class", "login-box", 4, "ngIf"], [1, "login-box"], [1, "login-logo"], ["href", "javascript:void(0)"], [1, "card"], [1, "card-body", "login-card-body"], [1, "login-box-msg"], [3, "ngSubmit", "formGroup"], [1, "input-group", "mb-3"], ["type", "email", "formControlName", "email", "placeholder", "Email", 1, "form-control"], [1, "input-group-append"], [1, "input-group-text"], [1, "fas", "fa-envelope"], [1, "row"], [1, "col-12"], ["type", "submit", 1, "btn", "btn-primary", "btn-block", 3, "disabled"], [1, "mt-3", "mb-1"], [3, "routerLink"], [1, "mb-0"], [1, "text-center", 3, "routerLink"], ["type", "password", "formControlName", "password", "placeholder", "Password", 1, "form-control"], [1, "fas", "fa-lock"], ["type", "password", "formControlName", "password_confirmation", "placeholder", "Confirm Password", 1, "form-control"], ["href", "login.html"]],
      template: function ResetPasswordComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ResetPasswordComponent_div_1_Template, 26, 6, "div", 1)(2, ResetPasswordComponent_div_2_Template, 28, 2, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.screen == "emailScreen");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.screen == "passwordScreen");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 73769:
/*!*******************************************************!*\
  !*** ./src/app/modules/auth/services/auth.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthService: () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var _core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../core/shared/utils/const */ 12549);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _core_shared_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../core/shared/utils/api-handler.service */ 14090);



class AuthService {
  constructor(http) {
    this.http = http;
  }
  signIn(data) {
    return this.http.requestCall(_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.logIn, _core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  resetPassword(data, token) {
    return this.http.requestCall(_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.resetPassword, _core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, token, data);
  }
  forgetPassword(data) {
    return this.http.requestCall(_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.forgetPassword, _core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  signUp(data) {
    return this.http.requestCall(_core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.signUp, _core_shared_utils_const__WEBPACK_IMPORTED_MODULE_0__.ApiMethod.POST, '', data);
  }
  logout() {
    localStorage.clear();
  }
  static {
    this.ɵfac = function AuthService_Factory(t) {
      return new (t || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_core_shared_utils_api_handler_service__WEBPACK_IMPORTED_MODULE_1__.ApiHandlerService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: AuthService,
      factory: AuthService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 51764:
/*!***********************************************************************!*\
  !*** ./src/app/modules/common/theme-toggle/theme-toggle.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemeToggleComponent: () => (/* binding */ ThemeToggleComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var src_app_services_theme_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/theme.service */ 70487);



class ThemeToggleComponent {
  constructor() {
    this.themeService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(src_app_services_theme_service__WEBPACK_IMPORTED_MODULE_0__.ThemeService);
  }
  toggleTheme() {
    this.themeService.toggleTheme();
  }
  static {
    this.ɵfac = function ThemeToggleComponent_Factory(t) {
      return new (t || ThemeToggleComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: ThemeToggleComponent,
      selectors: [["app-theme-toggle"]],
      decls: 3,
      vars: 8,
      consts: [[1, "btn", "btn-sm", 3, "click"], [1, "fas"]],
      template: function ThemeToggleComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ThemeToggleComponent_Template_button_click_0_listener() {
            return ctx.toggleTheme();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "i", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.themeService.currentTheme() === "dark" ? "btn-light" : "btn-dark");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-label", "Switch to " + (ctx.themeService.currentTheme() === "dark" ? "light" : "dark") + " mode");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("fa-sun", ctx.themeService.currentTheme() === "light")("fa-moon", ctx.themeService.currentTheme() === "dark");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.themeService.currentTheme() === "dark" ? "Light" : "Dark", " Mode\n");
        }
      },
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 78771:
/*!********************************************************************!*\
  !*** ./src/app/modules/common/theme-toggle/theme-toggle.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemeToggleModule: () => (/* binding */ ThemeToggleModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _theme_toggle_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./theme-toggle.component */ 51764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);



class ThemeToggleModule {
  static {
    this.ɵfac = function ThemeToggleModule_Factory(t) {
      return new (t || ThemeToggleModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: ThemeToggleModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ThemeToggleModule, {
    declarations: [_theme_toggle_component__WEBPACK_IMPORTED_MODULE_0__.ThemeToggleComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule],
    exports: [_theme_toggle_component__WEBPACK_IMPORTED_MODULE_0__.ThemeToggleComponent]
  });
})();

/***/ }),

/***/ 69260:
/*!***************************************************************!*\
  !*** ./src/app/modules/dashboard/dashboard-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DashboardRoutingModule: () => (/* binding */ DashboardRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 95072);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 69786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);




const routes = [{
  path: '',
  component: _dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent
}];
class DashboardRoutingModule {
  static {
    this.ɵfac = function DashboardRoutingModule_Factory(t) {
      return new (t || DashboardRoutingModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: DashboardRoutingModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](DashboardRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
  });
})();

/***/ }),

/***/ 69786:
/*!**********************************************************!*\
  !*** ./src/app/modules/dashboard/dashboard.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DashboardComponent: () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _core_default_layout_main_header_main_header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/default-layout/main-header/main-header.component */ 68089);
/* harmony import */ var _core_default_layout_main_sidebar_main_sidebar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/default-layout/main-sidebar/main-sidebar.component */ 39295);
/* harmony import */ var _core_default_layout_control_sidebar_control_sidebar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/default-layout/control-sidebar/control-sidebar.component */ 29969);
/* harmony import */ var _core_default_layout_main_footer_main_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/default-layout/main-footer/main-footer.component */ 46729);





class DashboardComponent {
  constructor() {}
  ngOnInit() {}
  static {
    this.ɵfac = function DashboardComponent_Factory(t) {
      return new (t || DashboardComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: DashboardComponent,
      selectors: [["app-dashboard"]],
      decls: 406,
      vars: 0,
      consts: [[1, "content-wrapper"], [1, "content-header"], [1, "container-fluid"], [1, "row", "mb-2"], [1, "col-sm-6"], [1, "m-0"], [1, "breadcrumb", "float-sm-right"], [1, "breadcrumb-item"], ["href", "#"], [1, "breadcrumb-item", "active"], [1, "content"], [1, "row"], [1, "col-lg-3", "col-6"], [1, "small-box", "bg-info"], [1, "inner"], [1, "icon"], [1, "ion", "ion-bag"], ["href", "#", 1, "small-box-footer"], [1, "fas", "fa-arrow-circle-right"], [1, "small-box", "bg-success"], [2, "font-size", "20px"], [1, "ion", "ion-stats-bars"], [1, "small-box", "bg-warning"], [1, "ion", "ion-person-add"], [1, "small-box", "bg-danger"], [1, "ion", "ion-pie-graph"], [1, "col-lg-7", "connectedSortable"], [1, "card"], [1, "card-header"], [1, "card-title"], [1, "fas", "fa-chart-pie", "mr-1"], [1, "card-tools"], [1, "nav", "nav-pills", "ml-auto"], [1, "nav-item"], ["href", "#revenue-chart", "data-toggle", "tab", 1, "nav-link", "active"], ["href", "#sales-chart", "data-toggle", "tab", 1, "nav-link"], [1, "card-body"], [1, "tab-content", "p-0"], ["id", "revenue-chart", 1, "chart", "tab-pane", "active", 2, "position", "relative", "height", "300px"], ["id", "revenue-chart-canvas", "height", "300", 2, "height", "300px"], ["id", "sales-chart", 1, "chart", "tab-pane", 2, "position", "relative", "height", "300px"], ["id", "sales-chart-canvas", "height", "300", 2, "height", "300px"], [1, "card", "direct-chat", "direct-chat-primary"], ["title", "3 New Messages", 1, "badge", "badge-primary"], ["type", "button", "data-card-widget", "collapse", 1, "btn", "btn-tool"], [1, "fas", "fa-minus"], ["type", "button", "title", "Contacts", "data-widget", "chat-pane-toggle", 1, "btn", "btn-tool"], [1, "fas", "fa-comments"], ["type", "button", "data-card-widget", "remove", 1, "btn", "btn-tool"], [1, "fas", "fa-times"], [1, "direct-chat-messages"], [1, "direct-chat-msg"], [1, "direct-chat-infos", "clearfix"], [1, "direct-chat-name", "float-left"], [1, "direct-chat-timestamp", "float-right"], ["src", "assets/dist/img/user1-128x128.jpg", "alt", "message user image", 1, "direct-chat-img"], [1, "direct-chat-text"], [1, "direct-chat-msg", "right"], [1, "direct-chat-name", "float-right"], [1, "direct-chat-timestamp", "float-left"], ["src", "assets/dist/img/user3-128x128.jpg", "alt", "message user image", 1, "direct-chat-img"], [1, "direct-chat-contacts"], [1, "contacts-list"], ["src", "assets/dist/img/user1-128x128.jpg", "alt", "User Avatar", 1, "contacts-list-img"], [1, "contacts-list-info"], [1, "contacts-list-name"], [1, "contacts-list-date", "float-right"], [1, "contacts-list-msg"], ["src", "assets/dist/img/user7-128x128.jpg", "alt", "User Avatar", 1, "contacts-list-img"], ["src", "assets/dist/img/user3-128x128.jpg", "alt", "User Avatar", 1, "contacts-list-img"], ["src", "assets/dist/img/user5-128x128.jpg", "alt", "User Avatar", 1, "contacts-list-img"], ["src", "assets/dist/img/user6-128x128.jpg", "alt", "User Avatar", 1, "contacts-list-img"], ["src", "assets/dist/img/user8-128x128.jpg", "alt", "User Avatar", 1, "contacts-list-img"], [1, "card-footer"], ["action", "#", "method", "post"], [1, "input-group"], ["type", "text", "name", "message", "placeholder", "Type Message ...", 1, "form-control"], [1, "input-group-append"], ["type", "button", 1, "btn", "btn-primary"], [1, "ion", "ion-clipboard", "mr-1"], [1, "pagination", "pagination-sm"], [1, "page-item"], ["href", "#", 1, "page-link"], ["data-widget", "todo-list", 1, "todo-list"], [1, "handle"], [1, "fas", "fa-ellipsis-v"], [1, "icheck-primary", "d-inline", "ml-2"], ["type", "checkbox", "value", "", "name", "todo1", "id", "todoCheck1"], ["for", "todoCheck1"], [1, "text"], [1, "badge", "badge-danger"], [1, "far", "fa-clock"], [1, "tools"], [1, "fas", "fa-edit"], [1, "fas", "fa-trash-o"], ["type", "checkbox", "value", "", "name", "todo2", "id", "todoCheck2", "checked", ""], ["for", "todoCheck2"], [1, "badge", "badge-info"], ["type", "checkbox", "value", "", "name", "todo3", "id", "todoCheck3"], ["for", "todoCheck3"], [1, "badge", "badge-warning"], ["type", "checkbox", "value", "", "name", "todo4", "id", "todoCheck4"], ["for", "todoCheck4"], [1, "badge", "badge-success"], ["type", "checkbox", "value", "", "name", "todo5", "id", "todoCheck5"], ["for", "todoCheck5"], [1, "badge", "badge-primary"], ["type", "checkbox", "value", "", "name", "todo6", "id", "todoCheck6"], ["for", "todoCheck6"], [1, "badge", "badge-secondary"], [1, "card-footer", "clearfix"], ["type", "button", 1, "btn", "btn-primary", "float-right"], [1, "fas", "fa-plus"], [1, "col-lg-5", "connectedSortable"], [1, "card", "bg-gradient-primary"], [1, "card-header", "border-0"], [1, "fas", "fa-map-marker-alt", "mr-1"], ["type", "button", "title", "Date range", 1, "btn", "btn-primary", "btn-sm", "daterange"], [1, "far", "fa-calendar-alt"], ["type", "button", "data-card-widget", "collapse", "title", "Collapse", 1, "btn", "btn-primary", "btn-sm"], ["id", "world-map", 2, "height", "250px", "width", "100%"], [1, "card-footer", "bg-transparent"], [1, "col-4", "text-center"], ["id", "sparkline-1"], [1, "text-white"], ["id", "sparkline-2"], ["id", "sparkline-3"], [1, "card", "bg-gradient-info"], [1, "fas", "fa-th", "mr-1"], ["type", "button", "data-card-widget", "collapse", 1, "btn", "bg-info", "btn-sm"], ["type", "button", "data-card-widget", "remove", 1, "btn", "bg-info", "btn-sm"], ["id", "line-chart", 1, "chart", 2, "min-height", "250px", "height", "250px", "max-height", "250px", "max-width", "100%"], ["type", "text", "data-readonly", "true", "value", "20", "data-width", "60", "data-height", "60", "data-fgColor", "#39CCCC", 1, "knob"], ["type", "text", "data-readonly", "true", "value", "50", "data-width", "60", "data-height", "60", "data-fgColor", "#39CCCC", 1, "knob"], ["type", "text", "data-readonly", "true", "value", "30", "data-width", "60", "data-height", "60", "data-fgColor", "#39CCCC", 1, "knob"], [1, "card", "bg-gradient-success"], [1, "btn-group"], ["type", "button", "data-toggle", "dropdown", "data-offset", "-52", 1, "btn", "btn-success", "btn-sm", "dropdown-toggle"], [1, "fas", "fa-bars"], ["role", "menu", 1, "dropdown-menu"], ["href", "#", 1, "dropdown-item"], [1, "dropdown-divider"], ["type", "button", "data-card-widget", "collapse", 1, "btn", "btn-success", "btn-sm"], ["type", "button", "data-card-widget", "remove", 1, "btn", "btn-success", "btn-sm"], [1, "card-body", "pt-0"], ["id", "calendar", 2, "width", "100%"]],
      template: function DashboardComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-main-header")(1, "app-main-sidebar");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 0)(3, "div", 1)(4, "div", 2)(5, "div", 3)(6, "div", 4)(7, "h1", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Dashboard");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 4)(10, "ol", 6)(11, "li", 7)(12, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Home");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "li", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, "Dashboard v1");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "section", 10)(17, "div", 2)(18, "div", 11)(19, "div", 12)(20, "div", 13)(21, "div", 14)(22, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "150");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, "New Orders");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](27, "i", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "a", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29, "More info ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](30, "i", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "div", 12)(32, "div", 19)(33, "div", 14)(34, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](35, "53");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "sup", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](37, "%");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](38, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, "Bounce Rate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](41, "i", 21);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](42, "a", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](43, "More info ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](44, "i", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](45, "div", 12)(46, "div", 22)(47, "div", 14)(48, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](49, "44");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](50, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](51, "User Registrations");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](52, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](53, "i", 23);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](54, "a", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](55, "More info ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](56, "i", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](57, "div", 12)(58, "div", 24)(59, "div", 14)(60, "h3");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](61, "65");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](62, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](63, "Unique Visitors");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](64, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](65, "i", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](66, "a", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](67, "More info ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](68, "i", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](69, "div", 11)(70, "section", 26)(71, "div", 27)(72, "div", 28)(73, "h3", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](74, "i", 30);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](75, " Sales ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](76, "div", 31)(77, "ul", 32)(78, "li", 33)(79, "a", 34);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](80, "Area");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](81, "li", 33)(82, "a", 35);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](83, "Donut");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](84, "div", 36)(85, "div", 37)(86, "div", 38);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](87, "canvas", 39);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](88, "div", 40);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](89, "canvas", 41);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](90, "div", 42)(91, "div", 28)(92, "h3", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](93, "Direct Chat");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](94, "div", 31)(95, "span", 43);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](96, "3");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](97, "button", 44);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](98, "i", 45);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](99, "button", 46);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](100, "i", 47);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](101, "button", 48);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](102, "i", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](103, "div", 36)(104, "div", 50)(105, "div", 51)(106, "div", 52)(107, "span", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](108, "Alexander Pierce");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](109, "span", 54);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](110, "23 Jan 2:00 pm");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](111, "img", 55);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](112, "div", 56);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](113, " Is this template really for free? That's unbelievable! ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](114, "div", 57)(115, "div", 52)(116, "span", 58);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](117, "Sarah Bullock");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](118, "span", 59);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](119, "23 Jan 2:05 pm");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](120, "img", 60);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](121, "div", 56);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](122, " You better believe it! ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](123, "div", 51)(124, "div", 52)(125, "span", 53);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](126, "Alexander Pierce");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](127, "span", 54);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](128, "23 Jan 5:37 pm");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](129, "img", 55);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](130, "div", 56);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](131, " Working with AdminLTE on a great new app! Wanna join? ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](132, "div", 57)(133, "div", 52)(134, "span", 58);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](135, "Sarah Bullock");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](136, "span", 59);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](137, "23 Jan 6:10 pm");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](138, "img", 60);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](139, "div", 56);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](140, " I would love to. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](141, "div", 61)(142, "ul", 62)(143, "li")(144, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](145, "img", 63);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](146, "div", 64)(147, "span", 65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](148, " Count Dracula ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](149, "small", 66);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](150, "2/28/2015");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](151, "span", 67);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](152, "How have you been? I was...");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](153, "li")(154, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](155, "img", 68);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](156, "div", 64)(157, "span", 65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](158, " Sarah Doe ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](159, "small", 66);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](160, "2/23/2015");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](161, "span", 67);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](162, "I will be waiting for...");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](163, "li")(164, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](165, "img", 69);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](166, "div", 64)(167, "span", 65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](168, " Nadia Jolie ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](169, "small", 66);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](170, "2/20/2015");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](171, "span", 67);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](172, "I'll call you back at...");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](173, "li")(174, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](175, "img", 70);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](176, "div", 64)(177, "span", 65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](178, " Nora S. Vans ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](179, "small", 66);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](180, "2/10/2015");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](181, "span", 67);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](182, "Where is your new...");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](183, "li")(184, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](185, "img", 71);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](186, "div", 64)(187, "span", 65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](188, " John K. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](189, "small", 66);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](190, "1/27/2015");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](191, "span", 67);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](192, "Can I take a look at...");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](193, "li")(194, "a", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](195, "img", 72);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](196, "div", 64)(197, "span", 65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](198, " Kenneth M. ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](199, "small", 66);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](200, "1/4/2015");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](201, "span", 67);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](202, "Never mind I found...");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](203, "div", 73)(204, "form", 74)(205, "div", 75);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](206, "input", 76);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](207, "span", 77)(208, "button", 78);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](209, "Send");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](210, "div", 27)(211, "div", 28)(212, "h3", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](213, "i", 79);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](214, " To Do List ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](215, "div", 31)(216, "ul", 80)(217, "li", 81)(218, "a", 82);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](219, "\u00AB");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](220, "li", 81)(221, "a", 82);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](222, "1");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](223, "li", 81)(224, "a", 82);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](225, "2");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](226, "li", 81)(227, "a", 82);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](228, "3");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](229, "li", 81)(230, "a", 82);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](231, "\u00BB");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](232, "div", 36)(233, "ul", 83)(234, "li")(235, "span", 84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](236, "i", 85)(237, "i", 85);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](238, "div", 86);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](239, "input", 87)(240, "label", 88);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](241, "span", 89);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](242, "Design a nice theme");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](243, "small", 90);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](244, "i", 91);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](245, " 2 mins");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](246, "div", 92);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](247, "i", 93)(248, "i", 94);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](249, "li")(250, "span", 84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](251, "i", 85)(252, "i", 85);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](253, "div", 86);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](254, "input", 95)(255, "label", 96);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](256, "span", 89);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](257, "Make the theme responsive");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](258, "small", 97);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](259, "i", 91);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](260, " 4 hours");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](261, "div", 92);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](262, "i", 93)(263, "i", 94);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](264, "li")(265, "span", 84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](266, "i", 85)(267, "i", 85);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](268, "div", 86);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](269, "input", 98)(270, "label", 99);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](271, "span", 89);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](272, "Let theme shine like a star");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](273, "small", 100);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](274, "i", 91);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](275, " 1 day");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](276, "div", 92);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](277, "i", 93)(278, "i", 94);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](279, "li")(280, "span", 84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](281, "i", 85)(282, "i", 85);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](283, "div", 86);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](284, "input", 101)(285, "label", 102);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](286, "span", 89);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](287, "Let theme shine like a star");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](288, "small", 103);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](289, "i", 91);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](290, " 3 days");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](291, "div", 92);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](292, "i", 93)(293, "i", 94);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](294, "li")(295, "span", 84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](296, "i", 85)(297, "i", 85);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](298, "div", 86);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](299, "input", 104)(300, "label", 105);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](301, "span", 89);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](302, "Check your messages and notifications");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](303, "small", 106);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](304, "i", 91);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](305, " 1 week");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](306, "div", 92);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](307, "i", 93)(308, "i", 94);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](309, "li")(310, "span", 84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](311, "i", 85)(312, "i", 85);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](313, "div", 86);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](314, "input", 107)(315, "label", 108);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](316, "span", 89);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](317, "Let theme shine like a star");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](318, "small", 109);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](319, "i", 91);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](320, " 1 month");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](321, "div", 92);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](322, "i", 93)(323, "i", 94);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](324, "div", 110)(325, "button", 111);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](326, "i", 112);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](327, " Add item");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](328, "section", 113)(329, "div", 114)(330, "div", 115)(331, "h3", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](332, "i", 116);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](333, " Visitors ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](334, "div", 31)(335, "button", 117);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](336, "i", 118);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](337, "button", 119);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](338, "i", 45);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](339, "div", 36);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](340, "div", 120);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](341, "div", 121)(342, "div", 11)(343, "div", 122);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](344, "div", 123);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](345, "div", 124);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](346, "Visitors");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](347, "div", 122);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](348, "div", 125);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](349, "div", 124);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](350, "Online");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](351, "div", 122);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](352, "div", 126);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](353, "div", 124);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](354, "Sales");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](355, "div", 127)(356, "div", 115)(357, "h3", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](358, "i", 128);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](359, " Sales Graph ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](360, "div", 31)(361, "button", 129);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](362, "i", 45);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](363, "button", 130);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](364, "i", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](365, "div", 36);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](366, "canvas", 131);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](367, "div", 121)(368, "div", 11)(369, "div", 122);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](370, "input", 132);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](371, "div", 124);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](372, "Mail-Orders");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](373, "div", 122);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](374, "input", 133);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](375, "div", 124);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](376, "Online");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](377, "div", 122);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](378, "input", 134);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](379, "div", 124);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](380, "In-Store");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](381, "div", 135)(382, "div", 115)(383, "h3", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](384, "i", 118);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](385, " Calendar ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](386, "div", 31)(387, "div", 136)(388, "button", 137);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](389, "i", 138);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](390, "div", 139)(391, "a", 140);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](392, "Add new event");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](393, "a", 140);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](394, "Clear events");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](395, "div", 141);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](396, "a", 140);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](397, "View calendar");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](398, "button", 142);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](399, "i", 45);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](400, "button", 143);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](401, "i", 49);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](402, "div", 144);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](403, "div", 145);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](404, "app-control-sidebar")(405, "app-main-footer");
        }
      },
      dependencies: [_core_default_layout_main_header_main_header_component__WEBPACK_IMPORTED_MODULE_0__.MainHeaderComponent, _core_default_layout_main_sidebar_main_sidebar_component__WEBPACK_IMPORTED_MODULE_1__.MainSidebarComponent, _core_default_layout_control_sidebar_control_sidebar_component__WEBPACK_IMPORTED_MODULE_2__.ControlSidebarComponent, _core_default_layout_main_footer_main_footer_component__WEBPACK_IMPORTED_MODULE_3__.MainFooterComponent],
      styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 47117:
/*!*******************************************************!*\
  !*** ./src/app/modules/dashboard/dashboard.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DashboardModule: () => (/* binding */ DashboardModule)
/* harmony export */ });
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 69786);
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard-routing.module */ 69260);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var src_app_core_default_layout_main_header_main_header_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/default-layout/main-header/main-header.module */ 59116);
/* harmony import */ var src_app_core_default_layout_main_sidebar_main_sidebar_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/default-layout/main-sidebar/main-sidebar.module */ 18558);
/* harmony import */ var src_app_core_default_layout_main_footer_main_footer_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/default-layout/main-footer/main-footer.module */ 76700);
/* harmony import */ var src_app_core_default_layout_control_sidebar_control_sidebar_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/default-layout/control-sidebar/control-sidebar.module */ 35604);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/card */ 53777);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37580);









class DashboardModule {
  static {
    this.ɵfac = function DashboardModule_Factory(t) {
      return new (t || DashboardModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
      type: DashboardModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__.DashboardRoutingModule, src_app_core_default_layout_main_header_main_header_module__WEBPACK_IMPORTED_MODULE_2__.MainHeaderModule, src_app_core_default_layout_main_sidebar_main_sidebar_module__WEBPACK_IMPORTED_MODULE_3__.MainSidebarModule, src_app_core_default_layout_control_sidebar_control_sidebar_module__WEBPACK_IMPORTED_MODULE_5__.ControlSidebarModule, src_app_core_default_layout_main_footer_main_footer_module__WEBPACK_IMPORTED_MODULE_4__.MainFooterModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_8__.MatCardModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](DashboardModule, {
    declarations: [_dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__.DashboardRoutingModule, src_app_core_default_layout_main_header_main_header_module__WEBPACK_IMPORTED_MODULE_2__.MainHeaderModule, src_app_core_default_layout_main_sidebar_main_sidebar_module__WEBPACK_IMPORTED_MODULE_3__.MainSidebarModule, src_app_core_default_layout_control_sidebar_control_sidebar_module__WEBPACK_IMPORTED_MODULE_5__.ControlSidebarModule, src_app_core_default_layout_main_footer_main_footer_module__WEBPACK_IMPORTED_MODULE_4__.MainFooterModule, _angular_material_card__WEBPACK_IMPORTED_MODULE_8__.MatCardModule]
  });
})();

/***/ }),

/***/ 70487:
/*!*******************************************!*\
  !*** ./src/app/services/theme.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemeService: () => (/* binding */ ThemeService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 37580);
// src/app/services/theme.service.ts


class ThemeService {
  constructor() {
    this.THEME_KEY = 'adminlte-theme';
    this.currentTheme = (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.signal)(this.getInitialTheme());
    // Apply theme when it changes
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.effect)(() => {
      this.applyTheme(this.currentTheme());
    });
    // Watch for system preference changes
    if (typeof window !== 'undefined') {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem(this.THEME_KEY)) {
          this.currentTheme.set(e.matches ? 'dark' : 'light');
        }
      });
    }
  }
  getInitialTheme() {
    if (typeof window === 'undefined') return 'light';
    const saved = localStorage.getItem(this.THEME_KEY);
    if (saved) return saved;
    // Check system preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  }
  toggleTheme() {
    this.currentTheme.set(this.currentTheme() === 'light' ? 'dark' : 'light');
    localStorage.setItem(this.THEME_KEY, this.currentTheme());
  }
  setTheme(theme) {
    this.currentTheme.set(theme);
    localStorage.setItem(this.THEME_KEY, theme);
  }
  applyTheme(theme) {
    if (typeof document === 'undefined') return;
    const html = document.documentElement;
    html.classList.remove('light-theme', 'dark-theme');
    html.classList.add(`${theme}-theme`);
    html.setAttribute('data-theme', theme);
  }
  static {
    this.ɵfac = function ThemeService_Factory(t) {
      return new (t || ThemeService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: ThemeService,
      factory: ThemeService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 45312:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
  production: true,
  api_url: 'http://localhost:3000/api/v1/',
  ws_url: 'http://localhost:3000',
  API_ALERT_ENDPOINT: 'http://localhost:3001/',
  API_PY_ENDPOINT: 'http://127.0.0.1:5000/',
  companyId: '1254863933218p0ppp'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

/***/ }),

/***/ 84429:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 80436);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 50635);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 45312);
/// <reference types="@angular/localize" />




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
  (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));
// bootstrapApplication(JsoneditorComponent).catch((err) => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(50886), __webpack_exec__(1643), __webpack_exec__(84429)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map